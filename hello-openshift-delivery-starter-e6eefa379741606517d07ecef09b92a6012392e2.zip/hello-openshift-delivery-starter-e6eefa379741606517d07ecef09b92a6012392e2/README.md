
# DSS-Starter

Proyecto de demostración de tecnologías, basado en Java 11, Spring Boot  2
y Spring Cloud Hoxton.

##  **Contexto**
 El contexto puede verse como un servicio que esta disponible en la plataforma DSS del cual se obtiene la información requerida para ejecutar peticiónes a diferentes origenes como B2H (BUS TO HOST), B2D (BUS TO DATA) Y B2E (BUS TO ENTERPRISE). la estructura inicial entregada por la plataforma es la siguiente:
 ```
    {
    "name": "nombre",
    "alias": "rut sin ceros, puntos ni guión",
    "userID": "n o id de la persona autenticada",
    }
  ```
 El contexto inicial es un objeto JSON con naturaleza par/valor, el cual puede enriquecerse según sea la demanda. Un contexto modificado ó enriquecido puede verse de la siguiente manera:
  ```
  {
    "name": "nombre",
    "alias": "rut sin ceros, puntos ni guión",
    "userID": "n o id de la persona autenticada",
    "user": "IATPUB1",
    "rut": "rut con ceros, sin puntos ni guión (11) espacios",
    "terminal": "(AND",
    "channel": "05"
 }
 ``` 
para ejemplificar un poco mejor el el flujo e2e de la ejecución de un microservicio haciendo uso de contexto, se muestran el siguiente diagrama de secuencia:
**Flujo e2e ejecución de microservicio con uso del contexto **

 ```mermaid
sequenceDiagram
FRONT END->>DSS GATEWAY: Solicitud enviada
DSS GATEWAY--xFRONT END: Solicitud rechazada
DSS GATEWAY->>DSS IAM: Solicitud de autenticación
DSS IAM--xFRONT END: Solicitud de autenticación rechazada
DSS IAM->>DSS TOKEN SESSION: Obtenemos token DSS y con el un contexto incial
DSS TOKEN SESSION->>DSS CONTEXT: Se crea contexto inicial
DSS CONTEXT->>FRONT END: Se entrega token jwt al frontend
FRONT END->>DSS GATEWAY: Nueva solicitud enviada
DSS GATEWAY->>MICROSERVICE: Redirecciona al microservicio
MICROSERVICE->>DSS CONTEXT: Consulta de informacion 
DSS CONTEXT->>MICROSERVICE: Contexto retorna informacion
MICROSERVICE->>(B2H/B2D/B2E): Consulta de datos
(B2H/B2D/B2E)->>MICROSERVICE: Retorna datos a MS
MICROSERVICE->> FRONT END: Retorna información consultada al front end
```

En el template se dispone el package **cl.santander.client.context** con los métodos para  realizar el fácil uso del consumo del servicio de contexto ( GET, POST, PUT, PATCH, DELETE ) .

## Programación Reactiva 
Las nuevas versiones de los microservicios implementan la programación reactiva con [Reactor.io](https://projectreactor.io/) el uso de expreseiones  [lambdas](https://www.oracle.com/lad/technical-resources/articles/java/expresiones-lambda-api-stream-java.html) y el uso de la pieza de consumo de diferentes origenes (BEAAS - Backend as a service) (B2H/B2D/B2E)

Flux ![enter image description here](https://profile.es/pro/wp-content/media/post-reactiva02.png)

Mono 
![enter image description here](https://profile.es/pro/wp-content/media/post-reactiva03.png)

##  **Logs y tributación a kafka**

Para la correcta utilización de los Logs es necesario hacer uso de los siguientes imports:
***import org.slf4j.Logger;***
***import org.slf4j.LoggerFactory;***
instanciandose de la siguiente manera:
**private final static Logger  LOGGER = LoggerFactory.getLogger( tuclase.class );**

``` yml
información incluida en el application.yml
app:
logging:
file:
enabled: true
dir: /tmp/logs
kafka:
enabled: true
bootstrap-servers: "dctamsbnr01.cl.bsch:9092"
topic: DSS.std-{MS NAME}
```
``` xml
 Usada para la tributacion hacia kafka a traves del archivo logback-spring.xml
	<springProperty scope="context" name="ROOT_LEVEL" source="app.logging.root-level" defaultValue="INFO"/>
	<springProperty scope="context" name="SHOULD_LOG_TO_FILE" source="app.logging.file.enabled"/>
	<springProperty scope="context" name="LOG_DIR" source="app.logging.file.dir"/>
	<springProperty scope="context" name="SHOULD_LOG_TO_KAFKA" source="app.logging.kafka.enabled"/>
	<springProperty scope="context" name="KAFKA_BOOTSTRAP_SERVERS" source="app.logging.kafka.bootstrap-servers"/>
	<springProperty scope="context" name="KAFKA_LOGSTASH_TOPIC" source="app.logging.kafka.topic"/>
```
##  **Kibana**
Para realizar la busqueda de logs por topicos tenemos la opción de usar Kibana
URL de acceso : [kibana home](http://dctaelknr01.cl.bsch:5601/app/kibana#/home?_g=())
* Ingresamos a la opción de [discovery](http://dctaelknr01.cl.bsch:5601/app/kibana#/discover?_g=()&_a=(columns:!(_source),index:'0946d130-c2fa-11ea-9d9b-152b40b72038',interval:auto,query:(language:kuery,query:''),sort:!('@timestamp',desc)))
* dentro de los campos disponibles seleccionamos  [logstash-dss-base](http://dctaelknr01.cl.bsch:5601/app/kibana#/discover?_g=()&_a=(columns:!(_source),index:fbcf6c10-b4d5-11ea-825e-25bb2d1ab7f0,interval:auto,query:(language:kuery,query:''),sort:!('@timestamp',desc)))
* Para realizar la busqueda realizamos el uso de los siguientes filtros :

	* **field:** KAFKA_LOGSTASCH_TOPIC.keyword 
	*  **operator:** is 
	* **value:** DSS.{MS NAME} - **Example: DSS.dss-gts-gateway** 
* **OR**
	* **field:** app-name 
	*  **operator:** is 
	* **value:** {MS NAME} - **Example: gts-gateway** 
	

## Demostraciones

* **Kafka**: Utilizado para enviar los logs de la aplicación como mensajes a un tópico. Los mensajes van en formato json compatible con logstash.
Este tópic pude ser, por ejemplo, directamente consumido por logstash para centralizar los logs (Elastic Stack)
Configuración: src/main/resources/logback-spring.xml

* **Swagger**: Utilizando springfox-swagger2, la aplicación genera documentación del microservicio.
Código: 
    * cl.santander.template.config.SwaggerConfig
    * Mirar las clases del package cl.santander.template.presentation
  
  Para acceder a la documentación: 
  ```
  http://localhost:9150/swagger-ui.html
  ```
es muy importante tener bien documentada la sección de swagger dentro del application.yml
``` yml
swagger:
  docs:
    title: titulo de tu microservicio 
    description:  descripción de tu microservicio
    version: 1.0.0 -> versión de tu microservicio
    terms: Product by Santander Chile -> debedejarse igual

```

* Manejo de excepciones, utilizando **@ControllerAdvice**: Se puede controlar el formato y estado http de las excepciones qu epuede lanzar la aplicación.
Código: 
    * cl.santander.template.presentation.handler.TemplateExceptionHandler: Controlador de exceptions
    * cl.santander.template.presentation.ExceptionHandlingExampleController: Controller que genera una exception
    * cl.santander.template.presentation.ExceptionHandlingExampleControllerTest: Prueba unitaria de la respuesta ante una excepción de negocio

* Cliente de servicio REST con webclient : Implementa un nuevo microservicio (demo) que expone una api REST. 

## Ambientes y prerrequisitos

### Prerrequisitos

* **Java JDK 11**. Las aplicaciones han sido desarrolladas y probadas con AdoptOpenJDK (https://adoptopenjdk.net/?variant=openjdk11&jvmVariant=hotspot)
* **docker**. Probada con versión 19.03.0
* **docker-compose**. Probada con versión 1.24.0

Además, es necesario tener acceso a internet paraque se puedan descargar las dependencias

### Preparación

Antes de ejecutar cualquiera de los distintos ambientes, 
es necesario construir DSS-Starter y las aplicaciones de compañía: demo, config-server y eureka-server.

Para probar en la consola, en el home del repositorio:

```
mvn compile package
java -Dspring.profiles.active=local -jar target/std-starter-1.0.2.jar
```

Se pueden construir de la siguiente forma:

```
./build-project.sh
```

Para probar en docker:

```
docker run -d --rm -e SPRING_PROFILES_ACTIVE=local -p 9150:9150 <nombre-de-imagen-en-pom.properties+tag>
````
Modificación de  archivo Docker-compose.yml:
```
version: '3.7'

services:

  dss-starter:
    image: docker.santander.cl/dss-starter #<-- debe ser modificado por el nombre de tu proyecto
    #environment:
    #  - SPRING_PROFILES_ACTIVE=docker-compose
    depends_on:
      - dss-discovery-service
      - dss-config-service
    networks:
      - microservices

networks:
  microservices:
    external:
      name: microservices

```
Modificación de archivo pom.properties
```
main.class=cl.santander.{starter}.StarterApplication // starter debe reemplazarse por nombre del paquete donde se aloja la clase principal
jar.file=std-template-1.0.2.jar // modificar con el nombre del artifactId + la version indicada en el pom.xml
docker.image.name=docker.santander.cl/std-template // docker.santander.cl/artifacdID
docker.image.tag=latest

```
## Perfiles

La aplicación Spring Boot tiene configurados los siguientes perfiles:

* local: No se registra con servicios de Spring Cloud (config, discovery). Sólo se conecta a bbdd/colas en localhost.
Ideal para realizar desarrollo y pruebas locales de la aplicación.

* local-compose: Utiliza servicios Spring Cloud y bbdd/colas apuntando a localhost. 
Ideal para probar la aplicación en un ambiente Cloud.

* docker-compose: Utiliza bbdd/colas dentro de la red creada por docker-compose, utilizando los nombres de servicio como hosts.
Este perfil es utlizado para levantar la aplicación como un servicio de apoyo que será utilizado por otra aplicación. La aplicación debe estar dentro de la red de docker-compose,
por lo que debe ser parte de una imagen docker y ser subida usando docker-compose.
Este perfil puede ser usado como base para configurar la aplicación en ambientes con contenedores, como Docker Swarm, Kubernetes o plataformas cloud.


## Configuraciones

### Kafka
```yaml
cache:
  hostnames:
    - "localhost:15701"
```

### Kafka

```yaml
app:
  logging:
    kafka:
      enabled: true
      bootstrap-servers: localhost:9092
      topic: logstash # debe de tener una estructura parecida a la siguiente DSS.std-{nombre de tu proyecto}
```

### PostgreSQL

```yaml
spring:
  datasource:
    url: jdbc:postgresql://localhost:15432/template
    username: template
    password: password
```

### Oracle DB

Para configurar la aplicación con conexión a la bbdd Oracle, se recomienda crear un perfil separado.

```yaml
spring:
  profiles: oracle-db
  datasource:
    url:
      jdbc:oracle:thin:@HOST:PORT:DB
    driver-class-name: oracle.jdbc.OracleDriver
    username: USER
    password: PASS
  jpa:
    properties:
      hibernate:
        dialect: org.hibernate.dialect.OracleDialect
        default_schema: SCHEMA_NAME
``` 

Nota: Los valores en mayúscula se reemplazan por los particulares de cada ambiente

Al levantar la aplicación, se deben indicar los perfiles con los que levantará, ya sea por system property, o por variable de ambiente:

`-Dspring.profiles.active=local,oracle-db` ó `SPRING_PROFILES_ACTIVE=local,oracle-db`

Y de esa forma se activa el ambiente y la configuración para la bbdd

Más información: https://docs.spring.io/spring-boot/docs/2.1.6.RELEASE/reference/htmlsingle/#howto-change-configuration-depending-on-the-environment
