package cl.santander.starter.request;

public class TemplateRequest {

}
