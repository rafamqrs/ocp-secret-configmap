package cl.santander.starter.request;

import lombok.Builder;
import lombok.Data;
@Builder
@Data
public class DeleteRequest {
	String token;
	String nameContext;
	
	
}
