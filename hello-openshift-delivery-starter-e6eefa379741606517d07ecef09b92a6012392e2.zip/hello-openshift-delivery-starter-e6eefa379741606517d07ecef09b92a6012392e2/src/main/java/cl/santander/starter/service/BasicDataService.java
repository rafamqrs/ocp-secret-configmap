package cl.santander.starter.service;

import java.util.HashMap;
import java.util.Map;
import java.util.UUID;
import java.util.concurrent.TimeUnit;

import javax.annotation.PostConstruct;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Component;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;

import cl.santander.beaas.model.AuthHost;
import cl.santander.beaas.model.Escalar;
import cl.santander.beaas.model.Input;
import cl.santander.beaas.model.Request;
import cl.santander.beaas.model.Response;
import cl.santander.beaas.model.Tx;
import cl.santander.beaas.service.B2Host;
import cl.santander.starter.client.context.ContextService;
import cl.santander.starter.client.functionalLogging.FunctionalLoggingSvc;
import cl.santander.starter.config.BeaasConfig;
import cl.santander.starter.config.DssConfig;
import cl.santander.starter.domain.BasicData;
import cl.santander.starter.domain.FunctionalLogging;
import cl.santander.starter.exception.ServiceException;
import cl.santander.starter.response.CustomerLegalResponse;
import cl.santander.starter.utils.Utils;
import reactor.core.publisher.Flux;
import reactor.core.publisher.Mono;
/**
 * tecnichal information:
 * 
 * spanish:
 * 
 * @PostConstruct: es una anotación utilizada en un método que debe ejecutarse
 * 				   después de realizar la inyección de dependencia para realizar cualquier
 *                 inicialización.
 * 
 * 
 * @Component: es la anotación Spring más genérica. Una clase de Java decorada
 * 			   con @Component se encuentra durante el escaneo de classpath y se registra
 *             en el contexto como un bean Spring.
 * 
 * @Autowired: Marca un constructor, campo, método de establecimiento o método de configuración como
 *             Ser conectado automáticamente por las instalaciones de inyección de dependencia de Spring.
 * 
 * english:
 * 
 * @PostConstruct: is an annotation used on a method that needs to be executed
 *                 after dependency injection is done to perform any
 *                 initialization.
 * 
 * @Component: is the most generic Spring annotation. A Java class decorated
 *             with @Component is found during classpath scanning and registered
 *             in the context as a Spring bean.
 *
 * @Autowired: Marks a constructor, field, setter method, or config method as to
 *             be autowired by Spring's dependency injection facilities.
 * 
 * Service that makes the call to the bus to host
 * 
 * @author id20576
 * @version 1.0.0
 * @author n727779(SGonzalez)
 * @version 1.0.1 15/06/2020 Method modification due to data model change
 * @version 1.0.2 03/08/2020 Modification parsing B2H response
 * @author id20576
 * @version 1.0.3 04/08/2021 add functional Logging and tecnhical information
 * 
 */

@Component
public class BasicDataService {
	private static final Logger log = LoggerFactory.getLogger(BasicDataService.class);
	
	/**
	 * injecting log functional
	 */
	@Autowired
	FunctionalLoggingSvc logging;
	
	FunctionalLogging data = new FunctionalLogging();
	/**
	 * injecting conf properties
	 */
	@Autowired
	BeaasConfig cfg;
	/**
	 * BeaasConfig cfg injecting dss properties
	 */
	@Autowired
	DssConfig dss;

	/**
	 * B2Host b2host Obtain host configuration
	 */
	private B2Host b2host;
	@Autowired
	private ContextService context;
	private ObjectMapper mapper;

	/**
	 * init() initialize the context
	 */
	@PostConstruct
	public void init() {
		b2host = new B2Host(cfg.getB2h().get("url"), cfg.getB2h().get("user"), cfg.getB2h().get("pass"),
				cfg.getB2h().get("globalId"));
		mapper = new ObjectMapper();

	}

	/**
	 * Method that returns the response of the Trx PEAA from the bus to host.
	 * 
	 * @param token
	 * @param documentNumber
	 * @param useCache
	 * @param recall
	 * @return
	 * @throws ServiceException
	 * @throws JsonProcessingException 
	 */
	@SuppressWarnings("unchecked")
	public Mono<CustomerLegalResponse> findBasicData(String token, String documentNumber, String useCache,
			String recall) throws ServiceException, JsonProcessingException {

		long start = System.nanoTime();
		String rutCliente = Utils.formattedRut(documentNumber);
		log.info(String.format("Start service : %s %s %s", rutCliente, useCache, recall));
		String authToken = token.split(" ")[1].trim();
		
		// Validate rut
		
		boolean isValid = Utils.validateRut(rutCliente);
		if (!isValid) {
			log.error("Bad Request: Invalid document number");
			throw new ServiceException(String.valueOf(HttpStatus.BAD_REQUEST.value()), "Invalid document number");
		}
		// Validate existence token
		if (authToken.equals("")) {
			log.error("Bad Request: Invalid token for service");
			throw new ServiceException(String.valueOf(HttpStatus.BAD_REQUEST.value()), "Token cannot be null");
		}

		HashMap<String, String> session = (HashMap<String, String>) context.getContext(authToken, "session").block();

		// Validate session
		if (null == session) {
			log.error("Bad Request: No session available");
			throw new ServiceException(String.valueOf(HttpStatus.BAD_REQUEST.value()),
					"The session context cannot be null.");
		}
		if (null == session.get("channel") || null == session.get("user")) {
			log.error("Bad Request: No session available, field channel or user is null");
			throw new ServiceException(String.valueOf(HttpStatus.BAD_REQUEST.value()),
					"The session context cannot be null.");
		}


		if (useCache.equalsIgnoreCase("true")) {
			HashMap<String, CustomerLegalResponse> basicDataContext = (HashMap<String, CustomerLegalResponse>) context.getContext(authToken, "basicData")
					.block();

			if (null != basicDataContext) {
				if (basicDataContext.containsKey(rutCliente)) {
					CustomerLegalResponse cache = mapper.convertValue(basicDataContext.get(rutCliente),
							CustomerLegalResponse.class);
					log.info("End service");
					long end = System.nanoTime();
					long time = (end - start);
					log.info("Elapsed time: " + String.valueOf(TimeUnit.NANOSECONDS.toMillis(time)) + "ms");
					return Mono.just(cache);
				}
			}
		}

		// Consume Tx PEAA
		Tx txPEAA = Tx.builder()
				.authHost(AuthHost.builder().canalId(session.get("channel")).usuarioAlt(session.get("user")).build())
				.txName("PEAA").recall("").build();
		txPEAA.getEscalar().add(new Escalar("PETIPDO", "R"));
		txPEAA.getEscalar().add(new Escalar("PENUMDO", rutCliente));

		Flux<Response> responseB2H = b2host.launch("customer-management", UUID.randomUUID().toString(),
				new Request(Input.builder().tx(txPEAA).build()));
		
		BasicData basicData = new BasicData();
		CustomerLegalResponse model = new CustomerLegalResponse();
		
		// Get the Response element of the Flux, always a Response Object arrives
		Mono<CustomerLegalResponse> response = responseB2H.flatMap(responseTx -> {
			if ("00".equals(responseTx.getStatusCode())) {
//				BasicData basicData = new BasicData();
				// Mapping to model class
				basicData.setEntity(responseTx.getFieldEscalar("ENTIDAD"));
				basicData.setPersonNum(responseTx.getFieldEscalar("PENUMPE"));
				basicData.setDocType(responseTx.getFieldEscalar("PETIPDO"));
				basicData.setDocNum(responseTx.getFieldEscalar("PENUMDO"));
				basicData.setDocSecuence(responseTx.getFieldEscalar("PESECDO"));
				basicData.setFantasyName(responseTx.getFieldEscalar("PENOMFA"));
				basicData.setBusinessName(responseTx.getFieldEscalar("PENOMPE"));
				basicData.setConstitutionDate(responseTx.getFieldEscalar("PEFECNA"));
				basicData.setLegalForm(responseTx.getFieldEscalar("PEFORJU"));
				basicData.setStartDateActivities(responseTx.getFieldEscalar("PEFECIN"));
				basicData.setAdmissionDate(responseTx.getFieldEscalar("PEFEING"));
				basicData.setExecutive(responseTx.getFieldEscalar("PENUMPU"));
				basicData.setAdmSubsidiary(responseTx.getFieldEscalar("PESUCAD"));
				basicData.setBusinessUnit(responseTx.getFieldEscalar("PEUNINE"));
				basicData.setIndicators(responseTx.getFieldEscalar("PEINDIC"));
				basicData.setDom1(responseTx.getFieldEscalar("PEDOM1"));
				basicData.setDom2(responseTx.getFieldEscalar("PEDOM2"));
				basicData.setPhone(responseTx.getFieldEscalar("PETELRF"));
				basicData.setTypeEntity(responseTx.getFieldEscalar("PETIPEN"));
				basicData.setQuoteBag(responseTx.getFieldEscalar("PECOTBO"));
				basicData.setProperty(responseTx.getFieldEscalar("PEPROEM"));
				basicData.setNacionality(responseTx.getFieldEscalar("PENACPE"));
				basicData.setCountryOrigin(responseTx.getFieldEscalar("PEPAIOR"));
				basicData.setCountryResidence(responseTx.getFieldEscalar("PEPAIRE"));
				basicData.setSubjectCode(responseTx.getFieldEscalar("PECODSU"));
				basicData.setAcquisitionChannel(responseTx.getFieldEscalar("PECANAL"));
				basicData.setCompanyStatus(responseTx.getFieldEscalar("PEESTPE"));
				basicData.setCompanyCondition(responseTx.getFieldEscalar("PECONPE"));
				basicData.setDocCondition(responseTx.getFieldEscalar("PECONDO"));
				basicData.setLegalReason1(responseTx.getFieldEscalar("PENOMA1"));
				basicData.setLegalReason2(responseTx.getFieldEscalar("PENOMA2"));
				basicData.setLegalReason3(responseTx.getFieldEscalar("PENOMA3"));
				basicData.setAnnualBilling(responseTx.getFieldEscalar("FACANU"));
				basicData.setNetEquity(responseTx.getFieldEscalar("PATNET"));
				basicData.setCurrency(responseTx.getFieldEscalar("PECODMO"));
				basicData.setEmployees(responseTx.getFieldEscalar("PECANPE"));
				basicData.setWritingDate(responseTx.getFieldEscalar("PEFESCR"));
				basicData.setNotary(responseTx.getFieldEscalar("PENOMNO"));
				basicData.setDissolutionDate(responseTx.getFieldEscalar("PEFECDI"));
				basicData.setExpirationDate(responseTx.getFieldEscalar("PEFECVD"));
				basicData.setLegalRepresentative(responseTx.getFieldEscalar("OBJESO1"));
				basicData.setSegment(responseTx.getFieldEscalar("PEACTRI"));
				basicData.setSubSegment(responseTx.getFieldEscalar("PESUBSE"));
				basicData.setTimeStampBasicData(responseTx.getFieldEscalar("PEHSTAM1"));
				basicData.setTimeStampOfficialCustomerRelation(responseTx.getFieldEscalar("PEHSTAM2"));
				basicData.setTimeStampAddresses(responseTx.getFieldEscalar("PEHSTAM3"));
				basicData.setTimeStampPhone(responseTx.getFieldEscalar("PEHSTAM4"));
				basicData.setTimeStampComplData1(responseTx.getFieldEscalar("PEHSTAM5"));
				basicData.setTimeStampComplData2(responseTx.getFieldEscalar("PEHSTAM6"));
				basicData.setTimeStampAdditionalName(responseTx.getFieldEscalar("PEHSTAM7"));

				model.setBasicData(basicData);
				// add metadata
				model.addMetadata("BasicData", responseTx.getStatusCode(), responseTx.getStatusMessage());

				return Mono.just(model);
			} else {
				log.error("ServiceError::" + responseTx.getStatusCode() + "-"+responseTx.getStatusMessage());
				HashMap<String, String> errors = new HashMap<String, String>();
				errors.put(responseTx.getStatusCode(), responseTx.getStatusMessage());

				// Log Funcional
				data.clear();
				data.getFields().put("event-code", "100");
				data.getFields().put("rut", documentNumber);
				data.getFields().put("ip", "0.0.0.0");
				data.getFields().put("detail-1", "0.0.0.0");
				try {
					logging.send(session.get("channel"), data);
				} catch (JsonProcessingException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
				// Fin Log Funcional 

				return Mono.error(new ServiceException(String.valueOf(HttpStatus.CONFLICT.value()),
						responseTx.getStatusCode() + "-" + responseTx.getStatusMessage(),errors));
			}
		}).next();
		
		//Create or update basicData context
		Map<String, CustomerLegalResponse> mapCache = new HashMap<String, CustomerLegalResponse>();
		mapCache.put(rutCliente, response.block());

		HashMap<String, String> basicDataContext = (HashMap<String, String>) context.getContext(authToken, "basicData").block();
		
		if (basicDataContext == null) {
			context.putContext(authToken, "basicData", mapCache, Long.valueOf(dss.getContext().get("timeToLive")));
		}else {
			context.patchContext(authToken, "basicData", mapCache, Long.valueOf(dss.getContext().get("timeToLive")));
		}		

		// Update session context
		context.patchContext(authToken, "session", session,
				Long.valueOf(dss.getContext().get("timeToLive")));		
		
		log.info("End service");
		long end = System.nanoTime();
		long time = (end - start);
		log.info("Elapsed time: " + String.valueOf(TimeUnit.NANOSECONDS.toMillis(time)) + "ms");

		 // Log Funcional
		 data.clear();
		 data.getFields().put("event-code", "100");
		 data.getFields().put("rut", documentNumber);
		 data.getFields().put("ip", "0.0.0.0");
		 data.getFields().put("detail-1", "0.0.0.0");
		 logging.send(session.get("channel"), data);
		 // Fin Log Funcional 

		return response;

	} // Method closure

	
}// Class closure
