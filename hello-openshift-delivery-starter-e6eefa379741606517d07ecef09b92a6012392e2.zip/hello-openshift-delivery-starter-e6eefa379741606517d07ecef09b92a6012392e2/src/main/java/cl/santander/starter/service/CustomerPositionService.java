package cl.santander.starter.service;

import java.util.ArrayList;
import java.util.Comparator;
import java.util.HashMap;
import java.util.List;
import java.util.UUID;
import java.util.stream.Collectors;

import javax.annotation.PostConstruct;

import com.fasterxml.jackson.databind.ObjectMapper;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Component;

import cl.santander.beaas.model.AuthHost;
import cl.santander.beaas.model.Escalar;
import cl.santander.beaas.model.Input;
import cl.santander.beaas.model.Request;
import cl.santander.beaas.model.Response;
import cl.santander.beaas.model.Tx;
import cl.santander.beaas.service.B2Host;
import cl.santander.starter.config.Constants;
import cl.santander.starter.client.context.ContextService;
import cl.santander.starter.client.functionalLogging.FunctionalLoggingSvc;
import cl.santander.starter.config.BeaasConfig;
import cl.santander.starter.domain.BusinessProduct;
import cl.santander.starter.domain.FunctionalLogging;
import cl.santander.starter.domain.LocationReference;
import cl.santander.starter.exception.ServiceException;
import cl.santander.starter.response.CustomerPositionResponse;
import reactor.core.publisher.Flux;
import reactor.core.publisher.Mono;

/**
 * tecnichal information:
 * 
 * spanish:
 * 
 * @PostConstruct: es una anotación utilizada en un método que debe ejecutarse
 * 				   después de realizar la inyección de dependencia para realizar cualquier
 *                 inicialización.
 * 
 * 
 * @Component: es la anotación Spring más genérica. Una clase de Java decorada
 * 			   con @Component se encuentra durante el escaneo de classpath y se registra
 *             en el contexto como un bean Spring.
 * 
 * @Autowired: Marca un constructor, campo, método de establecimiento o método de configuración como
 *             Ser conectado automáticamente por las instalaciones de inyección de dependencia de Spring.
 * 
 * english:
 * 
 * @PostConstruct: is an annotation used on a method that needs to be executed
 *                 after dependency injection is done to perform any
 *                 initialization.
 * 
 * @Component: is the most generic Spring annotation. A Java class decorated
 *             with @Component is found during classpath scanning and registered
 *             in the context as a Spring bean.
 *
 * @Autowired: Marks a constructor, field, setter method, or config method as to
 *             be autowired by Spring's dependency injection facilities.
 * 
 * @author id20576
 * @version v1.1.0 02/08/2020
 * 
 *
 */

@Component
public class CustomerPositionService {

	private static final Logger LOGGER = LoggerFactory.getLogger(CustomerPositionService.class);
	
	/**
	 * injecting log functional
	 */
	@Autowired
	FunctionalLoggingSvc logging;
	
	FunctionalLogging data = new FunctionalLogging();

	// inject api beaas configuration , from configuration file application.yml
	@Autowired
	private BeaasConfig cfg;

	// inject constants , from configuration file application.yml
	@Autowired
	private Constants cfg1;

	// inject webClient
	@Autowired
	private ContextService context;

	// variable of JSON serialization/deserialization
	private ObjectMapper mapper;

	// variable of type host
	private B2Host b2host;

	// variable use to apply recall
	HashMap<String, String> mapRecall;

	// Initializing host parameters, from configuration file application.yml
	@PostConstruct
	public void init() {
		b2host = new B2Host(cfg.getB2h().get("url"), cfg.getB2h().get("user"), cfg.getB2h().get("pass"),
				cfg.getB2h().get("globalId"));

		// inicialize JSON serialization/deserialization
		mapper = new ObjectMapper();
	}// clousure constructor

	/**
	 * method findByDocNumber
	 * 
	 * @param String token
	 * @param String documentNumber
	 * @param String useCache
	 * @param String recall
	 * @return CustomerPositionResponse
	 */
	@SuppressWarnings("unchecked")
	public CustomerPositionResponse findByDocNumber(String token, String documentNumber, String useCache,
			String recall) {

		LOGGER.info("Start service : {} {} {} {}", documentNumber, useCache, token, recall);

		// get session context
		Mono<Object> contextSession = context.getContext(token.split(" ")[1], "session");
		// get recall context
		Mono<Object> getRecall = context.getContext(token.split(" ")[1], "recall");

		// Validate session context
		if (contextSession.block() == null) {
			LOGGER.error("Bad request : No session available.");
			throw new ServiceException(String.valueOf(HttpStatus.BAD_REQUEST.value()),
					"The session context cannot be null.");
		}

		// assign context information into session variable
		HashMap<String, String> session = (HashMap<String, String>) contextSession.block();

		// validate if recall param is empty or validate if mapRecall get information
		if (recall.isEmpty() || mapRecall.get("KPM254F") == null) {

			mapRecall = new HashMap<String, String>();

		} else {
			// assign recall information into session variable
			mapRecall = (HashMap<String, String>) getRecall.block();
		}

		// session validation
		if (null == session) {
			LOGGER.error("Bad request : No session available.");
			throw new ServiceException(String.valueOf(HttpStatus.BAD_REQUEST.value()),
					"The session context cannot be null.");
		}

		// token validation
		if (token.split(" ")[1].trim().equals("")) {
			LOGGER.error("Bad request : Invalid token for service.");
			throw new ServiceException(String.valueOf(HttpStatus.BAD_REQUEST.value()), "Token cannot be null.");
		}

		// rut validation
		if (null == session.get("rut")) {
			LOGGER.error("Bad request : No session available, field RUT is null.");
			throw new ServiceException(String.valueOf(HttpStatus.BAD_REQUEST.value()),
					"The session context cannot be null.");
		} else {
			if (!documentNumber.equals(session.get("rut"))) {
				LOGGER.error("Bad request : ID of context is not the same as that of the request.");
				throw new ServiceException(String.valueOf(HttpStatus.BAD_REQUEST.value()),
						"The session context cannot be null.");
			}
		}

		// user validation
		if (null == session.get("user")) {
			LOGGER.error("Bad request : No session available, field USUARIO-ALT is null.");
			throw new ServiceException(String.valueOf(HttpStatus.BAD_REQUEST.value()),
					"The session context cannot be null.");
		}

		// channel validation
		if (null == session.get("channel")) {
			LOGGER.error("Bad request : No session available, field CANAL-ID is null.");
			throw new ServiceException(String.valueOf(HttpStatus.BAD_REQUEST.value()),
					"The session context cannot be null.");
		}

		// terminal validation
		if (null == session.get("terminal")) {
			LOGGER.error("Bad request : No session available, field TERMINAL is null.");
			throw new ServiceException(String.valueOf(HttpStatus.BAD_REQUEST.value()),
					"The session context cannot be null.");
		}

		// use of cache
		CustomerPositionResponse contextCust = mapper.convertValue(
				context.getContext(token.split(" ")[1], "customer-position").block(), CustomerPositionResponse.class);
		if (useCache.equalsIgnoreCase("true") && contextCust != null) {
			return contextCust;
		}

		try {
			// Initializing custom response
			CustomerPositionResponse custResponse = new CustomerPositionResponse();

			// Initializing trax configurations
			Tx txKP21 = Tx.builder()
					.authHost(
							AuthHost.builder().canalId(session.get("channel")).usuarioAlt(session.get("user")).build())
					.txName("KP21").recall(recall != null ? mapRecall.get("KP21") : "").build();

			// assign escalar trax fields
			txKP21.getEscalar().add(new Escalar("PTIPDOC", "R"));
			txKP21.getEscalar().add(new Escalar("PNUMDOC", documentNumber));
			txKP21.getEscalar().add(new Escalar("PCODCNL", "0003"));
			txKP21.getEscalar().add(new Escalar("KTPOCRU", "0043"));
			txKP21.getEscalar().add(new Escalar("PCDGENT", "0035"));

			// Initializing trax configurations
			Tx txPEGX = Tx.builder()
					.authHost(
							AuthHost.builder().canalId(session.get("channel")).usuarioAlt(session.get("user")).build())
					.txName("PEGX").recall(recall != null ? mapRecall.get("PEGX") : "").build();

			// assign escalar trax fields
			txPEGX.getEscalar().add(new Escalar("PETIPDO", "R"));
			txPEGX.getEscalar().add(new Escalar("PENUMDO", documentNumber));
			txPEGX.getEscalar().add(new Escalar("PECANAL", "0003"));
			txPEGX.getEscalar().add(new Escalar("PECRUCE", "0045"));
			txPEGX.getEscalar().add(new Escalar("PECDGEN", "0035"));
			txPEGX.getEscalar().add(new Escalar("PEESTRE", "A"));
			txPEGX.getEscalar().add(new Escalar("PEINDRE", "N"));

			// Initializing trax configurations
			Tx txPE62 = Tx.builder()
					.authHost(
							AuthHost.builder().canalId(session.get("channel")).usuarioAlt(session.get("user")).build())
					.txName("PE62").recall(recall != null ? mapRecall.get("PE62") : "").build();

			// assign escalar trax fields
			txPE62.getEscalar().add(new Escalar("TIPDOC", "R"));
			txPE62.getEscalar().add(new Escalar("PENUMDO", documentNumber));

			// execute transactions
			Flux<Response> resultKP21 = b2host.launch("customer-position", UUID.randomUUID().toString(),
					new Request(Input.builder().tx(txKP21).build()));
			Flux<Response> resultPEGX = b2host.launch("customer-position", UUID.randomUUID().toString(),
					new Request(Input.builder().tx(txPEGX).build()));
			Flux<Response> resultPE62 = b2host.launch("customer-position", UUID.randomUUID().toString(),
					new Request(Input.builder().tx(txPE62).build()));

			// combining Publisher in the same list response Flux.merge
			List<Response> total = Flux.merge(resultKP21, resultPEGX, resultPE62).collectList().block();

			if (total.stream().filter(response -> !response.getStatusCode().equals("00")).count() > 0) {
				HashMap<String, String> errors = new HashMap<String, String>();
				total.stream().parallel().forEach(response -> {
					LOGGER.error("Error message: {} {} ({})", response.getTxName(), response.getStatusMessage(),
							response.getStatusCode());
					errors.put(response.getTxName() + ":" + response.getStatusCode(), response.getStatusMessage());
				});
				throw new ServiceException(HttpStatus.MULTI_STATUS.toString(), "Unexpected backend response. ", errors);

			}
			// Initializing the list of domains to complete with the transaction information
			// retrieve to the host
			List<BusinessProduct> productsKP21 = new ArrayList<>();
			List<BusinessProduct> productsPEGX = new ArrayList<>();
			List<LocationReference> locationsPE62 = new ArrayList<>();

			// we iterate the list of information retrieved from the three executed transactions
			total.stream().parallel().forEach(response -> {
				LOGGER.info("Foreach : " + response.getTxName());
				// we check if when going through the list the map agrees with the transaction
				// to compare and that we want to obtain the information
				if (response.getTxName().equals("KP21")) {
					LOGGER.info("Parsing KP21");
					// settings the escalar values to the response
					custResponse.getParty().setName(response.getFieldEscalar("PNOMPER"));
					custResponse.getParty().setLastName(
							response.getFieldEscalar("PPRIAPE") + " " + response.getFieldEscalar("PSEGAPE"));
					custResponse.getParty().setPersonType(response.getFieldEscalar("PTIPPER"));
					custResponse.getParty().setDocumentType(response.getFieldEscalar("PTIPDOC"));
					custResponse.getParty().setDocumentNumber(response.getFieldEscalar("PNUMDOC"));
					custResponse.getParty().setPersonNumber(response.getFieldEscalar("PNUMPER"));
					response.getFilterMatriz("KPM254F").stream().parallel().forEach(row -> {
						productsKP21.add(BusinessProduct.builder().idProduct(row.getValue("PCODPRO"))
								.idSubproduct(row.getValue("PCODSUB")).contractNumber(row.getValue("PNUMCON"))
								.branchCode(row.getValue("PCODOFI")).description(row.getValue("PPROGLS"))
								.descriptionDetail(row.getValue("PSUBGLS")).statusDescription(row.getValue("PESTOPE"))
								.currencyCode(row.getValue("PCODMON")).commercialCode(row.getValue("PAGRCOM")).build());
					});
					if (response.getAviso() != null) {
						response.getAviso().getRow().stream().parallel().forEach(aviso -> {
							custResponse.addMetadata("aviso:KP21", aviso.getValue("CODIGO"),
									aviso.getValue("DESCRIPCION"));
						});
					}
					// assign values to HashMap depens the transaccion
					mapRecall.put("KP21", response.getRecall());
					custResponse.addMetadata("status:KP21", response.getStatusCode(), response.getStatusMessage());

				}
				if (response.getTxName().equals("PEGX")) {
					LOGGER.info("Parsing PEGX");
					response.getFilterMatriz("PEMGXS2").stream().parallel().forEach(row -> {

						// set the scalar values ​​to the response
						productsPEGX.add(BusinessProduct.builder().entityCode(row.getValue("BGCODEN"))
								.idProduct(row.getValue("BGPRODU")).idSubproduct(row.getValue("BGSUBPR"))
								.contractNumber(row.getValue("BGCTTO")).branchCode(row.getValue("BGOFICI"))
								.description(row.getValue("BGGLCOR")).descriptionDetail(row.getValue("BGGLLAR"))
								.statusDescription(row.getValue("BGGLEST")).cardNumber(row.getValue("BGNUPAN"))
								.build());
					});
					if (response.getAviso() != null) {
						response.getAviso().getRow().stream().parallel().forEach(aviso -> {
							custResponse.addMetadata("aviso:PEGX", aviso.getValue("CODIGO"),
									aviso.getValue("DESCRIPCION"));
						});
					}
					// assign values to HashMap depens the transaccion
					mapRecall.put("PEGX", response.getRecall());
					custResponse.addMetadata("status:PEGX", response.getStatusCode(), response.getStatusMessage());
				}
				if (response.getTxName().equals("PE62")) {
					custResponse.getParty().setBirthday(
							response.getFilterMatriz("PEM241").stream().findFirst().get().getValue("PEFECNA"));
					LOGGER.info("Parsing PE62");
					response.getFilterMatriz("PEM2420").stream().parallel().forEach(row -> {
						// set the scalar values ​​to the response
						locationsPE62.add(LocationReference.builder().streetName(row.getValue("PENOMCA"))
								.number(row.getValue("PENOMBL")).complement(row.getValue("PEOBSE1"))
								.neighborhood(row.getValue("PEDESCO")).city("").county("").country("CHILE")
								.postalCode(row.getValue("PECODPO"))
								.email(row.getValue("TIPDOM").equals("ELE") ? row.getValue("PEOBSE2") : "")
								.observation(!row.getValue("TIPDOM").equals("ELE") ? row.getValue("PEOBSE2") : "")
								.typeLocation(row.getValue("TIPDOM")).build());
					});
					if (response.getAviso() != null) {
						response.getAviso().getRow().stream().parallel().forEach(aviso -> {
							custResponse.addMetadata("aviso:PE62", aviso.getValue("CODIGO"),
									aviso.getValue("DESCRIPCION"));
						});
					}
					// assign values to HashMap depens the transaccion
					mapRecall.put("PE62", response.getRecall());
					custResponse.addMetadata("status:PE62", response.getStatusCode(), response.getStatusMessage());
				}

			});

			productsKP21.stream().parallel().forEach(p1 -> {
				productsPEGX.stream().filter(p2 -> p2.getContractNumber().equals(p1.getContractNumber())).findFirst()
						.ifPresentOrElse((v) -> {
							v.setCurrencyCode(p1.getCurrencyCode());
							v.setCommercialCode(p1.getCommercialCode());
							custResponse.getProducts().add(v);
						}, () -> {
							custResponse.getProducts().add(p1);
						});
			});

			custResponse.setProducts(custResponse.getProducts().stream()
					.sorted(Comparator.comparing(BusinessProduct::getIdProduct)).collect(Collectors.toList()));

			custResponse.getLocation().addAll(locationsPE62.stream().distinct().collect(Collectors.toList()));

			String guidRecall = UUID.randomUUID().toString();
			custResponse.addMetadata("reference", "recall", guidRecall);

			// Update recall context
			Mono<HttpStatus> statusRecall = context.putContext(token.split(" ")[1], "recall", mapRecall,
					Long.valueOf(cfg1.getConstants().get("timeToLive")));
			if (statusRecall.block().is2xxSuccessful()) {
				LOGGER.info("Update recall context...");
			} else {
				LOGGER.error(
						String.format("Error update recall map: %s", String.valueOf(statusRecall.block().value())));
			}

			// Update session context
			Mono<HttpStatus> status = context.patchContext(token.split(" ")[1], "session", session,
					Long.valueOf(cfg1.getConstants().get("timeToLive")));
			if (status.block().is2xxSuccessful()) {
				LOGGER.info("Update session context...");
			} else {
				LOGGER.error(String.format("Error update session context HttpCode: %s",
						String.valueOf(status.block().value())));
			}
			
			 // Log Funcional
			 data.clear();
			 data.getFields().put("event-code", "100");
			 data.getFields().put("rut", documentNumber);
			 data.getFields().put("ip", "0.0.0.0");
			 data.getFields().put("detail-1", "0.0.0.0");
			 logging.send(session.get("channel"), data);
			 // Fin Log Funcional 
			 
			 
			return custResponse;
		} catch (ServiceException e) {
			LOGGER.error("Service Error : {} {}", e.getCode(), e.getLocalizedMessage());
			throw new ServiceException(String.valueOf(HttpStatus.BAD_REQUEST.value()), e.getMessage(), e.getErrors());
		} catch (Exception e) {
			LOGGER.error("Service Error : {}", e.getLocalizedMessage());
			throw new ServiceException(String.valueOf(HttpStatus.BAD_REQUEST.value()), e.getMessage());
		}
		
		

	}

	/**
	 * method findByDocNumber
	 * 
	 * @param token
	 * @param useCache
	 * @param recall
	 * @return
	 */
	@SuppressWarnings("unchecked")
	public CustomerPositionResponse findByDocNumber(String token, String useCache, String recall) {
		
	

		LOGGER.info("Start service : {} {} {} {}", "", useCache, token, recall);
		// get session context
		Mono<Object> contextSession = context.getContext(token.split(" ")[1], "session");
		// get recall context
		Mono<Object> getRecall = context.getContext(token.split(" ")[1], "recall");

		// Validate session context
		if (contextSession.block() == null) {
			LOGGER.error("Bad request : No session available.");
			throw new ServiceException(String.valueOf(HttpStatus.BAD_REQUEST.value()),
					"The session context cannot be null.");
		}


		// assign context information into session variable
		HashMap<String, String> session = (HashMap<String, String>) contextSession.block();

		// validate if recall param is empty or validate if mapRecall get information
		if (recall.isEmpty() || mapRecall.get("KPM254F") == null) {

			mapRecall = new HashMap<String, String>();

		} else {
			// assign recall information into session variable
			mapRecall = (HashMap<String, String>) getRecall.block();
		}

		
		// session validation
		if (null == session) {
			LOGGER.error("Bad request : No session available.");
			throw new ServiceException(String.valueOf(HttpStatus.BAD_REQUEST.value()),
					"The session context cannot be null.");
		}
		
		// token validation
		if (token.split(" ")[1].trim().equals("")) {
			LOGGER.error("Bad request : Invalid token for service.");
			throw new ServiceException(String.valueOf(HttpStatus.BAD_REQUEST.value()), "Token cannot be null.");
		}
		
		// rut validation
		if (null == session.get("rut")) {
			LOGGER.error("Bad request : No session available, field RUT is null.");
			throw new ServiceException(String.valueOf(HttpStatus.BAD_REQUEST.value()),
					"The session context cannot be null.");
		}
		
		// user validation
		if (null == session.get("user")) {
			LOGGER.error("Bad request : No session available, field USUARIO-ALT is null.");
			throw new ServiceException(String.valueOf(HttpStatus.BAD_REQUEST.value()),
					"The session context cannot be null.");
		}
		// channel validation
		if (null == session.get("channel")) {
			LOGGER.error("Bad request : No session available, field CANAL-ID is null.");
			throw new ServiceException(String.valueOf(HttpStatus.BAD_REQUEST.value()),
					"The session context cannot be null.");
		}
		// terminal validation
		if (null == session.get("terminal")) {
			LOGGER.error("Bad request : No session available, field TERMINAL is null.");
			throw new ServiceException(String.valueOf(HttpStatus.BAD_REQUEST.value()),
					"The session context cannot be null.");
		}

		// use of cache
		CustomerPositionResponse contextCust = mapper.convertValue(
				context.getContext(token.split(" ")[1], "customer-position").block(), CustomerPositionResponse.class);
		if (useCache.equalsIgnoreCase("true") && contextCust != null) {
			return contextCust;
		}

		try {

			// initializing custom response
			CustomerPositionResponse custResponse = new CustomerPositionResponse();

			Tx txKP21 = Tx.builder().authHost(AuthHost.builder()
									.canalId(session.get("channel"))
									.usuarioAlt(session.get("user")).build())
									.txName("KP21").recall(recall != null ? mapRecall.get("KP21") : "").build();

			txKP21.getEscalar().add(new Escalar("PTIPDOC", "R"));
			txKP21.getEscalar().add(new Escalar("PNUMDOC", session.get("rut")));
			txKP21.getEscalar().add(new Escalar("PCODCNL", "0003"));
			txKP21.getEscalar().add(new Escalar("KTPOCRU", "0043"));
			txKP21.getEscalar().add(new Escalar("PCDGENT", "0035"));

			Tx txPEGX = Tx.builder().authHost(AuthHost.builder()
									.canalId(session.get("channel"))
									.usuarioAlt(session.get("user")).build())
									.txName("PEGX").recall(recall != null ? mapRecall.get("PEGX") : "").build();

			txPEGX.getEscalar().add(new Escalar("PETIPDO", "R"));
			txPEGX.getEscalar().add(new Escalar("PENUMDO", session.get("rut")));
			txPEGX.getEscalar().add(new Escalar("PECANAL", "0003"));
			txPEGX.getEscalar().add(new Escalar("PECRUCE", "0045"));
			txPEGX.getEscalar().add(new Escalar("PECDGEN", "0035"));
			txPEGX.getEscalar().add(new Escalar("PEESTRE", "A"));
			txPEGX.getEscalar().add(new Escalar("PEINDRE", "N"));

			Tx txPE62 = Tx.builder().authHost(AuthHost.builder()
								    .canalId(session.get("channel"))
								    .usuarioAlt(session.get("user")).build())
									.txName("PE62").recall(recall != null ? mapRecall.get("PE62") : "").build();

			txPE62.getEscalar().add(new Escalar("TIPDOC", "R"));
			txPE62.getEscalar().add(new Escalar("PENUMDO", session.get("rut")));

			// execute transactions
			Flux<Response> resultKP21 = b2host.launch("customer-position", UUID.randomUUID().toString(),
					new Request(Input.builder().tx(txKP21).build()));

			Flux<Response> resultPEGX = b2host.launch("customer-position", UUID.randomUUID().toString(),
					new Request(Input.builder().tx(txPEGX).build()));

			Flux<Response> resultPE62 = b2host.launch("customer-position", UUID.randomUUID().toString(),
					new Request(Input.builder().tx(txPE62).build()));

			// combining Publisher in the same list response
			List<Response> total = Flux.merge(resultKP21, resultPEGX, resultPE62).collectList().block();

		
			if (total.stream().filter(response -> !response.getStatusCode().equals("00")).count() > 0) {
				HashMap<String, String> errors = new HashMap<String, String>();
				total.stream().parallel().forEach(response -> {
					LOGGER.error("Error message: {} {} ({})", response.getTxName(), response.getStatusMessage(),
							response.getStatusCode());
					errors.put(response.getTxName() + ":" + response.getStatusCode(), response.getStatusMessage());
				});
				throw new ServiceException(HttpStatus.MULTI_STATUS.toString(), "Unexpected backend response. ", errors);

			}
			// Initializing the list of domains to complete with the transaction information
			// retrieve to the host
			List<BusinessProduct> productsKP21 = new ArrayList<>();
			List<BusinessProduct> productsPEGX = new ArrayList<>();
			List<LocationReference> locationsPE62 = new ArrayList<>();
			
			// we iterate the list of information retrieved from the three executed transactions
			total.stream().parallel().forEach(response -> {
				LOGGER.info("Foreach : " + response.getTxName());
				if (response.getTxName().equals("KP21")) {
					LOGGER.info("Parsing KP21");
					custResponse.getParty().setName(response.getFieldEscalar("PNOMPER"));
					custResponse.getParty().setLastName(
							response.getFieldEscalar("PPRIAPE") + " " + response.getFieldEscalar("PSEGAPE"));
					custResponse.getParty().setPersonType(response.getFieldEscalar("PTIPPER"));
					custResponse.getParty().setDocumentType(response.getFieldEscalar("PTIPDOC"));
					custResponse.getParty().setDocumentNumber(response.getFieldEscalar("PNUMDOC"));
					custResponse.getParty().setPersonNumber(response.getFieldEscalar("PNUMPER"));
					response.getFilterMatriz("KPM254F").stream().parallel().forEach(row -> {
						productsKP21.add(BusinessProduct.builder().idProduct(row.getValue("PCODPRO"))
								.idSubproduct(row.getValue("PCODSUB")).contractNumber(row.getValue("PNUMCON"))
								.branchCode(row.getValue("PCODOFI")).description(row.getValue("PPROGLS"))
								.descriptionDetail(row.getValue("PSUBGLS")).statusDescription(row.getValue("PESTOPE"))
								.currencyCode(row.getValue("PCODMON")).commercialCode(row.getValue("PAGRCOM")).build());
					});
					if (response.getAviso() != null) {
						response.getAviso().getRow().stream().parallel().forEach(aviso -> {
							custResponse.addMetadata("aviso:KP21", aviso.getValue("CODIGO"),
									aviso.getValue("DESCRIPCION"));
						});
					}
					// assign values to HashMap depens the transaccion
					mapRecall.put("KP21", response.getRecall());
					custResponse.addMetadata("status:KP21", response.getStatusCode(), response.getStatusMessage());

				}
				if (response.getTxName().equals("PEGX")) {
					LOGGER.info("Parsing PEGX");
					response.getFilterMatriz("PEMGXS2").stream().parallel().forEach(row -> {
						productsPEGX.add(BusinessProduct.builder().entityCode(row.getValue("BGCODEN"))
								.idProduct(row.getValue("BGPRODU")).idSubproduct(row.getValue("BGSUBPR"))
								.contractNumber(row.getValue("BGCTTO")).branchCode(row.getValue("BGOFICI"))
								.description(row.getValue("BGGLCOR")).descriptionDetail(row.getValue("BGGLLAR"))
								.statusDescription(row.getValue("BGGLEST")).cardNumber(row.getValue("BGNUPAN"))
								.build());
					});
					if (response.getAviso() != null) {
						response.getAviso().getRow().stream().parallel().forEach(aviso -> {
							custResponse.addMetadata("aviso:PEGX", aviso.getValue("CODIGO"),
									aviso.getValue("DESCRIPCION"));
						});
					}
					// assign values to HashMap depens the transaccion
					mapRecall.put("PEGX", response.getRecall());
					custResponse.addMetadata("status:PEGX", response.getStatusCode(), response.getStatusMessage());
				}
				if (response.getTxName().equals("PE62")) {
					custResponse.getParty().setBirthday(
							response.getFilterMatriz("PEM241").stream().findFirst().get().getValue("PEFECNA"));
					LOGGER.info("Parsing PE62");
					response.getFilterMatriz("PEM2420").stream().parallel().forEach(row -> {
						locationsPE62.add(LocationReference.builder().streetName(row.getValue("PENOMCA"))
								.number(row.getValue("PENOMBL")).complement(row.getValue("PEOBSE1"))
								.neighborhood(row.getValue("PEDESCO")).city("").county("").country("CHILE")
								.postalCode(row.getValue("PECODPO"))
								.email(row.getValue("TIPDOM").equals("ELE") ? row.getValue("PEOBSE2") : "")
								.observation(!row.getValue("TIPDOM").equals("ELE") ? row.getValue("PEOBSE2") : "")
								.typeLocation(row.getValue("TIPDOM")).build());
					});
					if (response.getAviso() != null) {
						response.getAviso().getRow().stream().parallel().forEach(aviso -> {
							custResponse.addMetadata("aviso:PE62", aviso.getValue("CODIGO"),
									aviso.getValue("DESCRIPCION"));
						});
					}
					// assign values to HashMap depens the transaccion
					mapRecall.put("PE62", response.getRecall());
					custResponse.addMetadata("status:PE62", response.getStatusCode(), response.getStatusMessage());
				}

			});

			productsKP21.stream().parallel().forEach(p1 -> {
				productsPEGX.stream().filter(p2 -> p2.getContractNumber().equals(p1.getContractNumber())).findFirst()
						.ifPresentOrElse((v) -> {
							v.setCurrencyCode(p1.getCurrencyCode());
							v.setCommercialCode(p1.getCommercialCode());
							custResponse.getProducts().add(v);
						}, () -> {
							custResponse.getProducts().add(p1);
						});
			});

			custResponse.setProducts(custResponse.getProducts().stream()
					.sorted(Comparator.comparing(BusinessProduct::getIdProduct)).collect(Collectors.toList()));

			custResponse.getLocation().addAll(locationsPE62.stream().distinct().collect(Collectors.toList()));

			String guidRecall = UUID.randomUUID().toString();
			custResponse.addMetadata("reference", "recall", guidRecall);

			// Update recall context
			Mono<HttpStatus> statusRecall = context.putContext(token.split(" ")[1], "recall", mapRecall,
					Long.valueOf(cfg1.getConstants().get("timeToLive")));
			if (statusRecall.block().is2xxSuccessful()) {
				LOGGER.info("Update recall context...");
			} else {
				LOGGER.error(
						String.format("Error update recall map: %s", String.valueOf(statusRecall.block().value())));
			}

			// Update session context
			Mono<HttpStatus> status = context.patchContext(token.split(" ")[1], "session", session,
					Long.valueOf(cfg1.getConstants().get("timeToLive")));
			if (status.block().is2xxSuccessful()) {
				LOGGER.info("Update session context...");
			} else {
				LOGGER.error(String.format("Error update session context HttpCode: %s",
						String.valueOf(status.block().value())));
			}
			
			 // Log Funcional
			 data.clear();
			 data.getFields().put("event-code", "100");
			 data.getFields().put("rut", session.get("rut"));
			 data.getFields().put("ip", "0.0.0.0");
			 data.getFields().put("detail-1", "0.0.0.0");
			 logging.send(session.get("channel"), data);
			 // Fin Log Funcional 
			 
			return custResponse;
		} catch (ServiceException e) {
			LOGGER.error("Service Error : {} {}", e.getCode(), e.getLocalizedMessage());
			throw new ServiceException(String.valueOf(HttpStatus.BAD_REQUEST.value()), e.getMessage(), e.getErrors());
		} catch (Exception e) {
			LOGGER.error("Service Error : {}", e.getLocalizedMessage());
			throw new ServiceException(String.valueOf(HttpStatus.BAD_REQUEST.value()), e.getMessage());
		}

		
	}

}
