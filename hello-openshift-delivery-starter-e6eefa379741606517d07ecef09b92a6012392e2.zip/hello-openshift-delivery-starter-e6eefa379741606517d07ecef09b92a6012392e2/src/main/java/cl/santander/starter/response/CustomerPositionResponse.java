package cl.santander.starter.response;

import java.io.Serializable;
import java.util.List;
import java.util.ArrayList;

import cl.santander.starter.domain.*;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.NoArgsConstructor;

/**
 * tecnichal information:
 * 
 * spanish:
 * 
 * @Data: crea getters y setters en tiempo de ejecución - parte de la libreria lombok
 * @Builder: usando el patrón Builder sin escribir código repetitivo, Podemos aplicar esta anotación a una Clase o un método.
 * @EqualsAndHashCode: genera código hash e iguala implementaciones a partir de los campos de su objeto.
 * @NoArgsConstructor: Genera constructores que no toman argumentos.
 * @AllArgsConstructor: genera un constructor con 1 parámetro para cada campo en su clase.
 * 
 * english:
 *  
 * @Data: create getters and setters at runtime - part of the lombok library
 * @Builder: using the Builder pattern without writing boilerplate code, We can apply this annotation to a Class or a method. 
 * @EqualsAndHashCode: Generates hashCode and equals implementations from the fields of your object.
 * @NoArgsConstructor: Generates constructors that take no arguments.
 * @AllArgsConstructor: generates a constructor with 1 parameter for each field in your class.
 * 
 * 
 * @author id20576
 * @version v1.1.0 02/08/2020
 * 
 *
 */
@Data 
@Builder
@EqualsAndHashCode(callSuper=false)
@NoArgsConstructor
@AllArgsConstructor
public class CustomerPositionResponse extends RestResponse implements Serializable{
	
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	private PartyReference party = new PartyReference();
	
	@Builder.Default
	private List<BusinessProduct> products = new ArrayList<BusinessProduct>();
	
	@Builder.Default
	private List<LocationReference> location = new ArrayList<LocationReference>();
	
}
