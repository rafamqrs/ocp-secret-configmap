package cl.santander.starter.config;
import java.util.Collections;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.core.env.Environment;

import springfox.documentation.builders.PathSelectors;
import springfox.documentation.builders.RequestHandlerSelectors;
import springfox.documentation.service.ApiInfo;
import springfox.documentation.service.Contact;
import springfox.documentation.spi.DocumentationType;
import springfox.documentation.spring.web.plugins.Docket;
import springfox.documentation.swagger2.annotations.EnableSwagger2;
/**
 * tecnichal information:
 * 
 * spanish:
 * @Configuration: Anotación para definir una clase de configuracion  para el framework
 * @ConfigurationProperties: Anotación para configuración externalizada. Agregue esto a una definición de clase o un método 
 * @Bean en una clase @Configuration si desea vincular y validar algunas Propiedades externas 
 * en este caso se hace referencia a la seccion swagger del archivo application.yml
 * 
 * @Data: crea getters y setters en tiempo de ejecución - parte de la libreria lombok
 * 
 * @EnableSwagger2: es un proyecto de código abierto utilizado para generar los documentos de la API REST para servicios web RESTful
 * 
 * @Bean: es una anotación a nivel de método y un análogo directo del elemento XML <bean/>
 * 
 * english:
 * @Configuration: Annotation to define a configuration class for the framework
 * @ConfigurationProperties: Annotation for externalized configuration. Add this to a class definition or a 
 * @Bean method in a @Configuration class if you want to bind and validate some external Properties
 * in this case reference is made to the swagger section of the application.yml file
 * 
 * @Data: create getters and setters at runtime - part of the lombok library.
 * 
 * @EnableSwagger2: is an open source project used to generate the REST API documents for RESTful web services.
 * 
 * @Bean: is a method-level annotation and a direct analog of the XML <bean/> element.
 * 
 * @author id20576
 * @version v1.1.0 02/08/2020
 * 
 *
 */
@Configuration
@ConfigurationProperties(prefix = "swagger")
@EnableSwagger2
public class SwaggerConfig {

	@Autowired
	private Environment env;
	
	/**
	 * Spanish:
	 * Docket api(): Esta configuración es suficiente para integrar Swagger 2 en un proyecto Spring Boot existente.
	 * 
	 * English:
	 * Docket api(): This configuration is enough to integrate Swagger 2 into an existing Spring Boot project.
	 */
	@Bean
	public Docket api() {
		return new Docket(DocumentationType.SWAGGER_2)
				.select()
				.apis(RequestHandlerSelectors.basePackage(cl.santander.starter.StarterApplication.class.getPackageName()))
				.paths(PathSelectors.any())
				.build()
				.apiInfo(apiInfo());
	}

	/**
	 * Spanish:
	 * ApiInfo apiInfo(): retorna información de la sección swagger del archivo application.yml.
	 * 
	 * English:
	 * ApiInfo apiInfo(): returns information from the swagger section of the application.yml file..
	 */
	private ApiInfo apiInfo() {
		return new ApiInfo(
				env.getProperty("swagger.docs.title"),
				env.getProperty("swagger.docs.description"),
				env.getProperty("swagger.docs.version"),
				env.getProperty("swagger.docs.terms"),
				new Contact("Santander", null, null),
				"License of API", "API license URL", Collections.emptyList());
	}

}