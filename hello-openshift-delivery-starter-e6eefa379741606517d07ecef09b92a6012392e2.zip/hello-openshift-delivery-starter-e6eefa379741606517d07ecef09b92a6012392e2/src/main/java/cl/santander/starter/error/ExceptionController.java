package cl.santander.starter.error;

import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.List;
import java.util.Set;

import javax.validation.ConstraintViolation;
import javax.validation.ConstraintViolationException;

import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.http.converter.HttpMessageNotReadableException;
import org.springframework.validation.BindingResult;
import org.springframework.validation.FieldError;
import org.springframework.web.bind.MethodArgumentNotValidException;
import org.springframework.web.bind.MissingServletRequestParameterException;
import org.springframework.web.bind.annotation.ControllerAdvice;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.context.request.WebRequest;
import org.springframework.web.servlet.mvc.method.annotation.ResponseEntityExceptionHandler;

import cl.santander.starter.exception.ServiceException;
/**
 * techical information:
 * 
 * spanish:
 * @ControllerAdvice: es una especialización de la anotación @Component que permite manejar 
 * excepciones en toda la aplicación en un componente de manejo global
 * 
 * @ExceptionHandler es una anotación para manejar excepciones en clases de manejador o métodos de manejador específicos.
 * 
 * @ResponseBody es una anotación Spring que vincula un valor de retorno de método al cuerpo de respuesta web
 * 
 * english:
 * 
 * @ControllerAdvice: is a specialization of the @Component annotation which allows to handle
 *  exceptions across the whole application in one global handling component
 * 
 * @ExceptionHandler is an annotation for handling exceptions in specific handler classes or handler methods.
 * 
 * @ResponseBody is a Spring annotation which binds a method return value to the web response body
 * 
 * 
 * @author id20576 {aastudillo}
 * @version v1.1.0 02/08/2020
 * 
 */
@ControllerAdvice
public class ExceptionController extends ResponseEntityExceptionHandler {
	/**
	 * @param HttpMessageNotReadableException ex
	 * @param HttpHeaders headers
	 * @param HttpStatus status
	 * @param WebRequest request
	 * @return buildResponseEntity
	 */
	@Override
	protected ResponseEntity<Object> handleHttpMessageNotReadable(HttpMessageNotReadableException ex,
			HttpHeaders headers, HttpStatus status, WebRequest request) {
		String message = "The request structure is invalid.";
		return buildResponseEntity(HttpStatus.BAD_REQUEST, message, ex.getMessage());
	}// closure method
	/**
	 * @param MissingServletRequestParameterException ex
	 * @param HttpHeaders headers
	 * @param HttpStatus status
	 * @param WebRequest request
	 * 
	 */
	@Override
	protected ResponseEntity<Object> handleMissingServletRequestParameter(MissingServletRequestParameterException ex,
			HttpHeaders headers, HttpStatus status, WebRequest request) {
		String message = "The variable is not present in the Endpoint path.";
		return buildResponseEntity(HttpStatus.BAD_REQUEST, message, ex.getMessage());
	}// closure method
	
	/**
	 * @param MethodArgumentNotValidException ex
	 * @param HttpHeaders headers
	 * @param HttpStatus status
	 * @param WebRequest request
	 * 
	 */
	@Override
	protected ResponseEntity<Object> handleMethodArgumentNotValid(MethodArgumentNotValidException ex,
			HttpHeaders headers, HttpStatus status, WebRequest request) {

		BindingResult result = ex.getBindingResult();
		List<FieldError> fieldErrors = result.getFieldErrors();
		List<String> errors = new ArrayList<>();
		for (FieldError fieldError : fieldErrors) {
			errors.add(fieldError.getDefaultMessage());
		}
		String message = "The input data has problems";
		return buildResponseEntity(HttpStatus.BAD_REQUEST, message, errors);

	}// closure method
	/**
	 * 
	 * @param ConstraintViolationException ex
	 * @param WebRequest request
	 * @return buildResponseEntity
	 */
	@ExceptionHandler({ ConstraintViolationException.class })
	public ResponseEntity<Object> handleConstraintViolation(ConstraintViolationException ex, WebRequest request) {
		Set<ConstraintViolation<?>> constraintViolations = ex.getConstraintViolations();
		List<String> errors = new ArrayList<>();
		for (ConstraintViolation<?> constraintViolation : constraintViolations) {
			errors.add(constraintViolation.getMessage());
		}
		String message = "A validation problem has occurred with the input data";
		return buildResponseEntity(HttpStatus.UNPROCESSABLE_ENTITY, message, errors);
	}// closure method
	
	/**
	 * 
	 * @param ServiceException ex
	 * @param WebRequest request
	 * @return buildResponseEntity
	 */
	@ExceptionHandler({ ServiceException.class })
	public ResponseEntity<Object> handleSchemaException(ServiceException ex, WebRequest request) {
		return buildResponseEntity(HttpStatus.valueOf(Integer.parseInt(ex.getCode())), ex.getMessage(), ex.getErrors());
	}// closure method

	/**
	 * 
	 * @param HttpStatus status
	 * @param String message
	 * @param String error
	 * @return buildResponseEntity
	 */
	private ResponseEntity<Object> buildResponseEntity(HttpStatus status, String message, String error) {
		List<String> errors = Arrays.asList(error);
		return buildResponseEntity(status, message, errors);
	}// closure method

	/**
	 * 
	 * @param HttpStatus status
	 * @param String message
	 * @param List<String> error
	 * @return ResponseEntity
	 */
	private ResponseEntity<Object> buildResponseEntity(HttpStatus status, String message, List<String> error) {
		ErrorResponse schemaError = new ErrorResponse(status.value(), message, error, LocalDateTime.now());
		return new ResponseEntity<>(schemaError, status);
	}// closure method
	
	/**
	 * 
	 * @param HttpStatus status
	 * @param String message
	 * @param HashMap<String, String> error
	 * @return ResponseEntity
	 */
	private ResponseEntity<Object> buildResponseEntity(HttpStatus status, String message, HashMap<String, String> error) {
		ErrorResponse schemaError = new ErrorResponse(status.value(), message, error, LocalDateTime.now());
		return new ResponseEntity<>(schemaError, status);
	}// closure method

	/**
	 * 
	 * @param Exception exception
	 * @return buildResponseEntity
	 */
	@ExceptionHandler(Exception.class)
	@ResponseBody
	public ResponseEntity<Object> handler(Exception exception) {

		if (exception.getCause().getCause() instanceof ConstraintViolationException) {
			
			ConstraintViolationException cons = (ConstraintViolationException) exception.getCause().getCause();
			Set<ConstraintViolation<?>> constraintViolations = cons.getConstraintViolations();
			
			String message = "A validation problem has occurred with the input data";
			List<String> errors = new ArrayList<>();
			for (ConstraintViolation<?> constraintViolation : constraintViolations) {
				errors.add(constraintViolation.getMessage());
			}

			return buildResponseEntity(HttpStatus.UNPROCESSABLE_ENTITY, message, errors);

		}
		
		List<String> errors = Arrays.asList(exception.getMessage());
		return buildResponseEntity(HttpStatus.CONFLICT, "Error inesperado", errors);
	}// closure method
}
