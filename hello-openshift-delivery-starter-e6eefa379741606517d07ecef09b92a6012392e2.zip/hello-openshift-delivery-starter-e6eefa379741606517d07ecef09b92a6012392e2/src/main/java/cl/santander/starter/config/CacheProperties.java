package cl.santander.starter.config;

import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.boot.context.properties.EnableConfigurationProperties;
import org.springframework.context.annotation.Configuration;
/**
 * tecnichal information:
 * 
 * spanish:
 * @Configuration: Anotación para definir una clase de configuracion  para el framework
 * @ConfigurationProperties: Anotación para configuración externalizada. Agregue esto a una definición de clase o un método 
 * @Bean en una clase @Configuration si desea vincular y validar algunas Propiedades externas
 * en este caso se hace referencia a la seccion cache del archivo application.yml
 * 
 * @EnableConfigurationProperties: esta explicitamente activado al usar @ConfigurationProperties
 * 
 * english:
 * @Configuration: Annotation to define a configuration class for the framework
 * @ConfigurationProperties: Annotation for externalized configuration. Add this to a class definition or a
 * @Bean method in a @Configuration class if you want to bind and validate some external Properties
 * in this case reference is made to the cache section of the application.yml file
 * 
 * @EnableConfigurationProperties: It is explicitly activated when using @ConfigurationProperties
 * 
 * @author id20576
 * @version v1.1.0 02/08/2020
 * 
 *
 */
@Configuration
@EnableConfigurationProperties
@ConfigurationProperties("cache")
public class CacheProperties {

	private String[] hostnames;

	public String[] getHostnames() {
		return hostnames;
	}

	public void setHostnames(String[] hostnames) {
		this.hostnames = hostnames;
	}

}
