package cl.santander.starter.client.functionalLogging;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;

import cl.santander.starter.domain.FunctionalLogging;

import java.util.concurrent.Future;

import org.apache.camel.Exchange;
import org.apache.camel.FluentProducerTemplate;
import org.apache.camel.component.kafka.KafkaConstants;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;



@Service
public class FunctionalLoggingSvcImpl implements FunctionalLoggingSvc {

  @Autowired
  FluentProducerTemplate producer;

  ObjectMapper mapper = new ObjectMapper();

  String key = "no-def";

  @SuppressWarnings("unused")
@Override
  public void send(String channel, FunctionalLogging data) throws JsonProcessingException {

    if (channel != null)
      key = channel;

    Future<Exchange> send = producer.withProcessor(exchange -> {
      exchange.getIn().setBody(mapper.writeValueAsString(data));
      exchange.getIn().setHeader(KafkaConstants.KEY, key);
    }).to("direct:functional-logging").asyncSend();

  }

}