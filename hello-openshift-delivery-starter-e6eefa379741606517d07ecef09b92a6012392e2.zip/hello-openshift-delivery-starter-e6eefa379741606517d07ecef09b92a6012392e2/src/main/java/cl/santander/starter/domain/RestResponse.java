package cl.santander.starter.domain;

import java.util.ArrayList;
import java.util.HashMap;

import com.fasterxml.jackson.annotation.JsonProperty;

/**
 * tenichal information:
 * 
 * spanish:
 * @JsonProperty: se utiliza para indicar el nombre de la propiedad externa, el nombre utilizado en formato de datos (JSON u otro formato de datos compatible)
 * 
 * english:
 * @JsonProperty: is used to indicate external property name, name used in data format (JSON or one of other supported data formats)
 * 
 * @author id20576
 * @version v1.1.0 02/08/2020
 */
public class RestResponse {

	@JsonProperty("_metadata_")
	private ArrayList<HashMap<String, String>> metadata = new ArrayList<>();

	/**
	 * Method to return arraylist of metadata
	 * @return ArrayList<HashMap<String, String>>
	 */
	public ArrayList<HashMap<String, String>> getMetadata() {
		return metadata;
	}// closoure method
	/**
	 * Method to collect the metadata
	 * @param String type
	 * @param String code
	 * @param String data
	 */
	public void addMetadata(String type, String code, String data) {
		HashMap<String, String> ht = new HashMap<String, String>();
		
		ht.put("type", type);
		ht.put("code", code);
		ht.put("data", data);
		
		metadata.add(ht);
	}// closoure method
	
	
}
