package cl.santander.starter.error;

import java.time.LocalDateTime;
import java.util.Arrays;
import java.util.HashMap;
import java.util.List;

import com.fasterxml.jackson.annotation.JsonFormat;


/**
 * Exception enviada desde el microservicio de esquemas.
 * 
 * @author castudillo
 * 
 * tenichal information:
 * 
 * spanish:
 * @JsonProperty: se utiliza para indicar el nombre de la propiedad externa, el nombre utilizado en formato de datos (JSON u otro formato de datos compatible)
 * 
 * english:
 * @JsonProperty: is used to indicate external property name, name used in data format (JSON or one of other supported data formats)
 * 
 * @author id20576
 * @version v1.1.0 02/08/2020
 */
public class ErrorResponse{

	private final int code;
	private final String message;
	private final List<String> errors;
	private final HashMap<String, String> errorsDetails;
	@JsonFormat(shape = JsonFormat.Shape.STRING, pattern = "dd-MM-yyyy hh:mm:ss")
	private final LocalDateTime timestamp;
	
	/**
	 * 
	 * @param int code
	 * @param String message
	 * @param List<String> errors
	 * @param LocalDateTime timestamp
	 */
	public ErrorResponse(int code, String message, List<String> errors, LocalDateTime timestamp) {
		super();
		this.code = code;
		this.message = message;
		this.errors = errors;
		this.timestamp = timestamp;
		this.errorsDetails = null;
	}// closoure construct
	/**
	 * 
	 * @param int code
	 * @param String message
	 * @param String error
	 * @param LocalDateTime timestamp
	 */
	public ErrorResponse(int code, String message, String error, LocalDateTime timestamp) {
		super();
		this.code = code;
		this.message = message;
		errors = Arrays.asList(error);
		this.timestamp = timestamp;
		this.errorsDetails = null;
	}// closoure construct
	
	/**
	 * 
	 * @param int code
	 * @param String message
	 * @param HashMap<String, String> error
	 * @param LocalDateTime timestamp
	 */
	public ErrorResponse(int code, String message, HashMap<String, String> error, LocalDateTime timestamp) {
		super();
		this.code = code;
		this.message = message;
		errors = Arrays.asList("ServiceException");;
		this.timestamp = timestamp;
		this.errorsDetails = error;
	}// closoure construct

	/** GETTERS & SETTERS*/
	public int getCode() {
		return code;
	}

	public String getMessage() {
		return message;
	}

	public List<String> getErrors() {
		return errors;
	}

	public LocalDateTime getTimestamp() {
		return timestamp;
	}
	
	public HashMap<String, String> getErrorsDetails() {
		return errorsDetails;
	}


}