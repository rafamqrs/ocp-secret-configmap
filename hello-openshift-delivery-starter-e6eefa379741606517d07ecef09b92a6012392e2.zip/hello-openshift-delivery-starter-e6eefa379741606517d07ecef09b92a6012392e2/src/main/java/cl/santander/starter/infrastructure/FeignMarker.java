package cl.santander.starter.infrastructure;

public class FeignMarker {

}
