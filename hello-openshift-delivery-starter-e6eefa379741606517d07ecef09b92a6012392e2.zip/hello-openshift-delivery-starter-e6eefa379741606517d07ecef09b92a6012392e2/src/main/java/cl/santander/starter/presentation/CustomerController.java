package cl.santander.starter.presentation;


import org.springframework.boot.actuate.endpoint.annotation.ReadOperation;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestHeader;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.fasterxml.jackson.core.JsonProcessingException;

import cl.santander.starter.exception.ServiceException;
import cl.santander.starter.response.CustomerLegalResponse;
import cl.santander.starter.service.BasicDataService;
import io.swagger.annotations.ApiOperation;
import lombok.extern.slf4j.Slf4j;
import reactor.core.publisher.Mono;
/**
 * Technical information:
 * 
 * spanish:
 * 
 * @RestController es una anotaci�n de conveniencia para crear controladores Restful.
 * Es una especializaci�n de @Component y se detecta autom�ticamente mediante el escaneo de classpath.
 * Agrega las anotaciones @Controller y @ResponseBody
 * 
 * GET: solicitud HTTP que obtiene una representaci�n del recurso especificado.
 * PUT: solicitud HTTP que crea un nuevo elemento o reemplaza una representaci�n del elemento de destino con los datos de la solicitud.
 * POST: solicitud HTTP que crea un nuevo elemento. El tipo del cuerpo de la solicitud se indica mediante el encabezado Content-Type.
 * PATCH: solicitud HTTP que solo le permite reemplazar completamente un recurso.
 * DELETE: solicitud HTTP que permite eliminar un recurso.
 * 
 * @ApiOpetaion : Describe una operaci�n o t�picamente un m�todo HTTP en una ruta espec�fica.
 * @ApiOperation: (Elemento requerido => valor) - valor: corresponde al campo de resumen de la operaci�n. 
 * @GetMapping: la anotaci�n asigna solicitudes HTTP GET a m�todos de controlador espec�ficos.
 * 
 * english:
 * 
 * @RestController: annotation was introduced in Spring 4.0 to simplify the creation of RESTful web services.
 *  It's a convenience annotation that combines @Controller and @ResponseBody
 *  which eliminates the need to annotate every request handling method of the controller class with the @ResponseBody annotation.
 * 
 * GET: The HTTP GET method requests a representation of the specified resource.
 * PUT: The HTTP PUT request creates a new element or replaces a representation of the destination element with the request data.
 * POST: The HTTP POST method sends data to the server. The type of the request body is indicated by the Content-Type header.
 * PATCH: The HTTP PUT method only allows you to completely replace a document.
 * DELETE: The HTTP DELETE request method deletes the specified resource.
 * 
 * @ApiOpetaion : Describes an operation or typically a HTTP method against a specific path.
 * @ApiOperation: (Required Element  => value) - value : Corresponds to the summary field of the operation.
 *  
 * @GetMapping: shortcut for @RequestMapping(method = RequestMethod.GET) 
 * @PutMapping: shortcut for @RequestMapping(method = RequestMethod.PUT) 
 * @PostDelete: shortcut for @RequestMapping(method =RequestMethod.DELETE)
 * @PatchMapping - shortcut for @RequestMapping(method = RequestMethod.PATCH)
 * @DeleteMapping - shortcut for @RequestMapping(method =RequestMethod.DELETE)
 *
 * BasicDataService - Controller class defining endpoints for PEAA transaction
 * consumption
 * 
 * @author id20576
 * @version 1.0.0
 *
 * @author n727779(SGonzalez)
 * @version 1.0.1 01/06/2020 servNormData final private variable is added
 *          findNormativeDataLegal method is added
 *          
 * @author n727779(SGonzalez)
 * @version 1.0.2 15/06/2020 servSupplementary final private variable is added
 *          findSupplementaryDataLegal method is add
 *          findByDocNumber method name change by findBasicData     
 *          
 * @author id20576
 * @version 1.0.3 04/08/2021 add functional Logging and tecnhical information
 */

@RestController
@Slf4j
public class CustomerController {
	
	private final BasicDataService servBasicData;

	
	/**
	 * Builder of the controller
	 * 
	 * @param service
	 */
	public CustomerController(BasicDataService servBasicData) {
		this.servBasicData = servBasicData;

	}
	
	/**
	 * Method that returns the response of the Trx PEAA from the bus to host.
	 * 
	 * @param AUTHORIZATION
	 * @param customer_id   is the identity document number of the person to search
	 *                      (RUT)
	 * @param useCache
	 * @param recall
	 * @return returns the response from the bus to host mapped with the parameters
	 *         defined in the BasicDataResponse object.
	 * @see BasicDataResponse
	 * @throws ServiceException
	 * @throws JsonProcessingException 
	 */
	@ReadOperation
	@ApiOperation(value = "End point for consulting basic data of a legal customer")
	@GetMapping("/v1/{customer_id}/basicDataLegal")
	public Mono<ResponseEntity<CustomerLegalResponse>> findBasicDataLegal(
			@RequestHeader(value = "Authorization", required = true) String AUTHORIZATION,
			@RequestHeader(required = false) String xSantanderClientId,
			@RequestHeader(required = false) String xB3TraceId,
			@RequestHeader(required = false) String xB3ParentSpanId,
			@RequestHeader(required = false) String xB3SpanId,
			@RequestHeader(required = false) String xB3Sampled,
			@PathVariable(required = true) String customer_id,
			@RequestParam(required = false, defaultValue = "false") String useCache,
			@RequestParam(required = false, defaultValue = "") String recall) throws ServiceException, JsonProcessingException {
		log.info("Start method findByDocNumber");

		Mono<ResponseEntity<CustomerLegalResponse>> response;
		response = servBasicData.findBasicData(AUTHORIZATION, customer_id, useCache, recall)
				.map(p -> ResponseEntity.ok().contentType(MediaType.APPLICATION_JSON).body(p));
		log.info("End method findByDocNumber");

		return response;
	}// Method closure



}// Class closure
