package cl.santander.starter;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.boot.autoconfigure.kafka.KafkaAutoConfiguration;
import org.springframework.cloud.client.discovery.EnableDiscoveryClient;

/**
 * spanish:
 * Información tecnica:
 * 
 * @SpringBootApplication:
 * Utilizado para la configuración automática, el escaneo de componentes y se puedan definir configuraciones adicionales en su clase de aplicación.
 * La anotacion @SpringBootApplication habilita tres  caracteristicas:
 * @EnableAutoConfiguration: habilita el mecanismo de configuración automática de Spring Boot.
 * @ComponentScan: habilita el escaneo @Component en el paquete donde se encuentra la aplicación.
 * @Configuration: permite registrar beans adicionales en el contexto o importar clases de configuración adicionales.
 * 
 * @EnableDiscoveryClient: activa la implementación DiscoveryClient de Netflix Eureka.
 * 
 * english:
 * Technical information:
 * @SpringBootApplication
 * annotation can be used to enable those three features, that is:
 * @EnableAutoConfiguration: enable Spring Boot’s auto-configuration mechanism.
 * @ComponentScan: enable @Component scan on the package where the application is located.
 * @Configuration: allow to register extra beans in the context or import additional configuration classes.
 * 
 * @EnableDiscoveryClient: activates the Netflix Eureka DiscoveryClient implementation. 
 * 
 * @author id20576 {aastudillo}
 * @version v1.1.0 
 */
@SpringBootApplication
@EnableDiscoveryClient
public class StarterApplication {

	public static void main(String[] args) {
		SpringApplication.run(StarterApplication.class, args);
	}
	
}
