package cl.santander.starter.config;

import java.util.HashMap;

import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.boot.context.properties.EnableConfigurationProperties;
import org.springframework.context.annotation.Configuration;

import lombok.Data;
/**
 * tecnichal information:
 * 
 * spanish:
 * @Configuration: Anotación para definir una clase de configuracion  para el framework
 * @ConfigurationProperties: Anotación para configuración externalizada. Agregue esto a una definición de clase o un método 
 * @Bean en una clase @Configuration si desea vincular y validar algunas Propiedades externas 
 * en este caso se hace referencia a la seccion beaas del archivo application.yml
 * 
 * @Data: crea getters y setters en tiempo de ejecución - parte de la libreria lombok
 * 
 * @EnableConfigurationProperties: esta explicitamente activado al usar @ConfigurationProperties
 * 
 * english:
 * @Configuration: Annotation to define a configuration class for the framework
 * @ConfigurationProperties: Annotation for externalized configuration. Add this to a class definition or a 
 * @Bean method in a @Configuration class if you want to bind and validate some external Properties
 * in this case reference is made to the beaas section of the application.yml file
 * 
 * @Data: create getters and setters at runtime - part of the lombok library
 * 
 * @EnableConfigurationProperties: It is explicitly activated when using @ConfigurationProperties
 *
 * @author id20576
 * @version v1.1.0 02/08/2020
 * 
 *
 */
@Data
@Configuration
@EnableConfigurationProperties
@ConfigurationProperties(prefix = "beaas")
public class  BeaasConfig{
    private HashMap<String, String> b2h;
    private HashMap<String, String> b2d;
    private HashMap<String, String> b2e;
    private String secretKey;
    
	public HashMap<String, String> getB2h() {
		return b2h;
	}
	public void setB2h(HashMap<String, String> b2h) {
		this.b2h = b2h;
	}
}