package cl.santander.starter.domain;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;
/**
 * tecnichal information:
 * 
 * spanish:
 * @Data: crea getters y setters en tiempo de ejecución - parte de la libreria lombok.
 * @Builder: se usa para generar constructores para producir instancias de su propia clase.
 * @NoArgsConstructor generará un constructor sin parámetros.
 * @AllArgsConstructor: Genera un constructor con todos los argumentos.
 *
 * english:
 * @Data: create getters and setters at runtime - part of the lombok library
 * @Builder: it is used to generate constructors to produce instances of its own class.
 * @NoArgsConstructor will generate a constructor with no parameters.
 * @AllArgsConstructor: Generates an all-args constructor.
 * 
 * @author id20576
 * @version v1.1.0 02/08/2020
 * 
 *
 */
@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class PartyReference {

	private String personType; 
	private String personNumber;
	private String documentType;
	private String documentNumber;
	private String name;
	private String lastName;
	private String birthday;
	
}
