package cl.santander.starter.config;


import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.core.env.Environment;

import io.swagger.v3.oas.models.OpenAPI;
import io.swagger.v3.oas.models.info.Contact;
import io.swagger.v3.oas.models.info.Info;
import io.swagger.v3.oas.models.info.License;
@ConfigurationProperties(prefix = "swagger")
@Configuration
public class OpenApiConfig {
	
	@Autowired
	Environment env;
	


	@Bean
	OpenAPI openApi() {
		return new OpenAPI()
				.info(info());
	}

	private Info info() {
		return new Info()
				.title(env.getProperty("swagger.config.api-info.title"))
				.description(env.getProperty("swagger.config.api-info.description"))
				.version(env.getProperty("swagger.config.api-info.version"))
				.termsOfService(env.getProperty("swagger.config.api-info.terms"))
				.contact(
						new Contact()
								.name("Santander Chile")
								.url("API license URL")
								.email("API license Email"))
				.license(
						new License()
								.name(env.getProperty("swagger.config.api-info.license.name"))
								.url(""));
	}


}
