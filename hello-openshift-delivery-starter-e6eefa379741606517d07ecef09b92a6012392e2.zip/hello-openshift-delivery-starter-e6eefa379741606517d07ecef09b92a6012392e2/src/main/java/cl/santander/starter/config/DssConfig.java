package cl.santander.starter.config;

import java.util.HashMap;

import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.context.annotation.Configuration;

import lombok.Data;


/**
 * tecnichal information:
 * 
 * spanish:
 * @Configuration: Anotación para definir una clase de configuracion  para el framework
 * @ConfigurationProperties: Anotación para configuración externalizada. Agregue esto a una definición de clase o un método 
 * @Bean en una clase @Configuration si desea vincular y validar algunas Propiedades externas
 * en este caso se hace referencia a la seccion dss del archivo application.yml
 * 
 * @Data: crea getters y setters en tiempo de ejecución - parte de la libreria lombok
 * 
 * english:
 * @Configuration: Annotation to define a configuration class for the framework
 * @ConfigurationProperties: Annotation for externalized configuration. Add this to a class definition or a
 * @Bean method in a @Configuration class if you want to bind and validate some external Properties
 * in this case reference is made to the dss section of the application.yml file
 *  
 * @Data: create getters and setters at runtime - part of the lombok library
 *  
 * @author id20576
 * @version v1.1.0 02/08/2020
 * 
 *
 */
@Data
@Configuration
@ConfigurationProperties(prefix = "dss")
public class DssConfig {
    private HashMap<String, String> context;

	public HashMap<String, String> getContext() {
		return context;
	}

	public void setContext(HashMap<String, String> context) {
		this.context = context;
	}
}