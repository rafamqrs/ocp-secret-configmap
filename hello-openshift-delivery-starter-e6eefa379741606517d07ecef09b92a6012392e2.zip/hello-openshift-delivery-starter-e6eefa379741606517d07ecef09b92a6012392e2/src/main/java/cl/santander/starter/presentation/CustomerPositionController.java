package cl.santander.starter.presentation;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.http.HttpStatus;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestHeader;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import cl.santander.starter.exception.ServiceException;
import cl.santander.starter.response.CustomerPositionResponse;
import cl.santander.starter.service.CustomerPositionService;
import cl.santander.starter.utils.Utils;
import io.swagger.annotations.ApiOperation;
/**
 * Techical information:
 * 
 * spanish:
 * 
 * @RestController es una anotación de conveniencia para crear controladores Restful.
 * Es una especialización de @Component y se detecta automáticamente mediante el escaneo de classpath.
 * Agrega las anotaciones @Controller y @ResponseBody
 * 
 * @ApiOpetaion : Describe una operación o típicamente un método HTTP en una ruta específica.
 * @ApiOperation: (Elemento requerido => valor) - valor: corresponde al campo de resumen de la operación. 
 * @GetMapping: la anotación asigna solicitudes HTTP GET a métodos de controlador específicos.
 * 
 * @RequestHeader: la anotación vincula los valores de encabezado de solicitud a los parámetros del método.
 * Si el parámetro del método es Map <String, String>, MultiValueMap <String, String>,
 * o HttpHeaders, el mapa se rellena con todos los nombres y valores de encabezado.
 * 
 * @PathVariable: es una anotación Spring que indica que un parámetro de método debe estar vinculado a una variable de plantilla URI.
 * 
 * @RequestParam: es una anotación Spring utilizada para vincular un parámetro de solicitud web a un parámetro de método.
 * 
 * english:
 * 
 * @RestController is a convenience annotation for creating Restful controllers.
 * It is a specialization of @Component and is autodetected through classpath scanning.
 * It adds the @Controller and @ResponseBody annotations
 * 
 * @ApiOpetaion : Describes an operation or typically a HTTP method against a specific path.
 * @ApiOperation: (Required Element  => value) - value : Corresponds to the summary field of the operation. 
 * @GetMapping: annotation maps HTTP GET requests onto specific handler methods.
 * 
 * @RequestHeader: annotation binds request header values to method parameters.
 * If the method parameter is Map<String, String>, MultiValueMap<String, String>,
 * or HttpHeaders then the map is populated with all header names and values.
 * 
 * @PathVariable: is a Spring annotation which indicates that a method parameter should be bound to a URI template variable.
 * 
 * @RequestParam: is a Spring annotation used to bind a web request parameter to a method parameter.
 * 
 * @author id20576 {aastudillo}
 * @version v1.1.0 
 */
@RestController
public class CustomerPositionController {
	
	private static final Logger LOGGER = LoggerFactory.getLogger(CustomerPositionController.class);

	private final CustomerPositionService service;

	public CustomerPositionController(CustomerPositionService service) {
		this.service = service;
	}

	/**	
	 * 
	 * @param String AUTHORIZATION
	 * @param String dni
	 * @param String backend
	 * @param String useCache
	 * @param String recall
	 * @return CustomerPositionResponse
	 */
	@ApiOperation(value = "Endpoint to query data by dni") //Endpoint para consultar datos de template
	@GetMapping("/v1/customers-position/{dni}")
	public CustomerPositionResponse findCustomer(
												@RequestHeader(value = "Authorization", required = true) String AUTHORIZATION,
												@PathVariable String dni,
												@RequestHeader(required = false) String xSantanderClientId,
												@RequestHeader(required = false) String xB3TraceId,
												@RequestHeader(required = false) String xB3ParentSpanId,
												@RequestHeader(required = false) String xB3SpanId,
												@RequestHeader(required = false) String xB3Sampled,
												@RequestParam(required = false, defaultValue = "PBO") String backend,
												@RequestParam(required = false, defaultValue = "false") String useCache,
												@RequestParam(required = false, defaultValue = "") String recall) {
		CustomerPositionResponse responseService = new CustomerPositionResponse();;
		LOGGER.info("Initiating method GET ");
		
			if(Utils.validateRut(dni)) {
				if (backend.equals("PBO")){
					responseService = service.findByDocNumber(AUTHORIZATION, Utils.formattedRut(dni), useCache, recall);
					LOGGER.info("Finalizing method GET");
				}
				return responseService;
			}else {
	            throw new ServiceException(HttpStatus.CONFLICT.toString(), "Invalid customer id. ");

			}

	}//closure method
	
	/** 
	 * 
	 * @param String AUTHORIZATION
	 * @param String useCache
	 * @param String recall
	 * @return CustomerPositionResponse
	 */
	@ApiOperation(value = "Endpoint to query template data") //Endpoint para consultar datos de template
	@GetMapping("/v1/customers-position")
	public CustomerPositionResponse findCustomer(
												@RequestHeader(value = "Authorization", required = true) String AUTHORIZATION,
												@RequestHeader(required = false) String xSantanderClientId,
												@RequestHeader(required = false) String xB3TraceId,
												@RequestHeader(required = false) String xB3ParentSpanId,
												@RequestHeader(required = false) String xB3SpanId,
												@RequestHeader(required = false) String xB3Sampled,
												@RequestParam(required = false, defaultValue = "false") String useCache,
												@RequestParam(required = false, defaultValue = "") String recall) {
		LOGGER.info("Initiating method GET ");
		final CustomerPositionResponse responseService = service.findByDocNumber(AUTHORIZATION, useCache, recall);
		LOGGER.info("Finalizing method GET");
		return responseService;
	}//closure method
	
}
