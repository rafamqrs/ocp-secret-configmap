package cl.santander.starter.response;

import java.io.Serializable;

import cl.santander.starter.domain.RestResponse;

public class TemplateResponse extends RestResponse implements Serializable{
	
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	
	/*
	 *  Aquí se debe agregar las instancia de clases del dominio
	 *  
	 *  Here you must add the class instances of the domain
	 */
	
	
	
}
