package cl.santander.starter.response;

import com.fasterxml.jackson.annotation.JsonInclude;


import cl.santander.starter.domain.BasicData;
import cl.santander.starter.domain.RestResponse;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.EqualsAndHashCode;

/**
 * Legal Person Response Model
 * @author n727779(Sergio Gonzalez)
 * @version 1.0.0 29/05/2020
 */

@Data
@Builder
@EqualsAndHashCode(callSuper=false)
@AllArgsConstructor
//@NoArgsConstructor
@JsonInclude(JsonInclude.Include.NON_EMPTY)
public class CustomerLegalResponse extends RestResponse{
	
	private BasicData basicData;
	

	public CustomerLegalResponse() {
		
	}
}