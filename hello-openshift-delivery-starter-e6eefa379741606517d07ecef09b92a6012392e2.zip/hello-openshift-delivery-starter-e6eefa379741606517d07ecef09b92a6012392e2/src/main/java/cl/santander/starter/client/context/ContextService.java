package cl.santander.starter.client.context;

import org.springframework.http.HttpStatus;

import reactor.core.publisher.Mono;

/**
 * Interface to define methods of context services
 * 
 * @author n727779(SGonzalez)
 * @version 1.0.0 03/06/2020
 */
public interface ContextService {
	
	public Mono<HttpStatus> putContext(String token, String nameContext, Object obj, long timeToLive);
	public Mono<Object> getContext(String token, String nameContext);
	public Mono<HttpStatus> patchContext(String token, String nameContext, Object obj, long timeToLive);
	public Mono<HttpStatus> postContext(String token, String nameContext,Object obj, long timeToLive);
	public Mono<HttpStatus> deleteContext(String token, String nameContext);


}
