package cl.santander.starter.presentation;

import org.springframework.web.bind.annotation.RestController;
import lombok.extern.slf4j.Slf4j;
import io.swagger.annotations.ApiOperation;

import java.util.Date;

import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestParam;

@RestController
@Slf4j
public class MainController {
	
	@ApiOperation(value = "Holi Operation")
	@GetMapping("/")
	public String  holi(
			@RequestParam(required = false, name = "user" ) String user) {
		log.info("Start method findByDocNumber");

		return "Hola "+user+" "+ new Date() ;
	}

}
