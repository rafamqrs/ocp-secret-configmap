package cl.santander.starter.service;

import org.apache.camel.LoggingLevel;
import org.apache.camel.builder.RouteBuilder;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;

import lombok.extern.slf4j.Slf4j;

@Component
@Slf4j
public class AsynchronousServices extends RouteBuilder {
    
    @Value("${dss.functional-logging.kafka.bootstrap-servers}")
    private String bootstrapKafka;

    @Value("${dss.functional-logging.kafka.topic}")
    private String topic;

    @Override
    public void configure() throws Exception {
        from("direct:functional-logging")
                .streamCaching()
                .routeId("functional-logging")
                .log(LoggingLevel.DEBUG, log, "functional-logging")
                .to("kafka:"+topic+"?brokers="+bootstrapKafka);
    }
    
    
}
