package cl.santander.starter.exception;

import java.time.LocalDateTime;
import java.util.HashMap;

import com.fasterxml.jackson.annotation.JsonFormat;
/**
 * tenichal information:
 * 
 * spanish:
 * @JsonProperty: se utiliza para indicar el nombre de la propiedad externa, el nombre utilizado en formato de datos (JSON u otro formato de datos compatible)
 * 
 * english:
 * @JsonProperty: is used to indicate external property name, name used in data format (JSON or one of other supported data formats)
 * 
 * @author id20576
 * @version v1.1.0 02/08/2020
 */
public class ServiceException extends RuntimeException {

	private static final long serialVersionUID = 4442125330868704757L;

	private String code;

	@JsonFormat(shape = JsonFormat.Shape.STRING, pattern = "dd-MM-yyyy hh:mm:ss")
	private LocalDateTime timestamp;

	private HashMap<String, String> errors;


	/**
	 * @param String code
	 * @param message message
	 */
	public ServiceException(String code, String message) {
		super(message);
		this.code = code;
		this.timestamp = LocalDateTime.now();

	}// closoure construct
	
	/**
	 * 
	 * @param String code
	 * @param String message
	 * @param HashMap<String,String> errors
	 */
	public ServiceException(String code, String message, HashMap<String,String> errors) {
		super(message);
		this.code = code;
		this.timestamp = LocalDateTime.now();
		this.errors = errors;

	}// closoure construct
	/**
	 * 
	 * GETTERS & SETTERS
	 */
	public String getCode() {
		return code;
	}

	public LocalDateTime getTimestamp() {
		return timestamp;
	}

	public HashMap<String, String> getErrors() {
		return errors;
	}

}