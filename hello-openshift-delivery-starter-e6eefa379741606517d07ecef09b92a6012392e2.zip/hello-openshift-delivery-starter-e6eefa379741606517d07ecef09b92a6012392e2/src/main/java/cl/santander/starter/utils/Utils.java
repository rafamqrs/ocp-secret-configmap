package cl.santander.starter.utils;


import java.util.regex.Matcher;
import java.util.regex.Pattern;

/**
 * 
 * Utility class
 * @author n727779
 * @version 1.0.0 17/06/2020
 */

/**
 * 
 * @author n727779
 * @version 1.0.0
 */
public class Utils {
	public static boolean validateRut(String rut) {

		boolean isValid;
		Pattern pattern = Pattern.compile("[0-9]+-?[0-9kK]{1}$");
		Matcher matcher = pattern.matcher(rut);
		boolean resutlPattern = matcher.matches();

		if (resutlPattern) {
			String rutNoDv = rut.trim().substring(0, rut.length() - 1).replaceAll("\\D", "").replaceFirst("^0+", "");
			String dv = rut.substring(rut.length() - (1));
			int factor = 2;
			int suma = 0;

			for (int i = rutNoDv.length() - 1; i >= 0; i--) {
				suma += Integer.parseInt(rutNoDv.substring(i, i + 1)) * factor;
				if (factor == 7) {
					factor = 1;
				}
				factor++;
			}

			int dvResult = 11 - (suma % 11);
			if (dvResult == 10 && dv.equalsIgnoreCase("K")) {
				isValid = true;
				return isValid;
			} else if (dvResult == 11 && dv.equals("0")) {
				isValid = true;
				return isValid;
			} else if (dvResult == Integer.parseInt(dv)) {
				isValid = true;
				return isValid;
			}
			
		}
		isValid = false;
		return isValid;
	}
	
	public static String formattedRut(String rut) {
		String rutNoDv = rut.trim().substring(0, rut.length() - 1).replaceAll("\\D", "").replaceFirst("^0+", "");
		String dv = rut.substring(rut.length() - (1));
		return String.format("%010d", Integer.parseInt(rutNoDv))+dv;
	}
	

	
}
