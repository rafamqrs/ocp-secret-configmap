package cl.santander.starter.domain;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class FunctionalLogging {

	HashMap<String, String> fields = new HashMap<String, String>();
    List<HashMap<String, String>> details = new ArrayList<HashMap<String, String>>();
	
    public void clear(){
        fields.clear();
        details.clear();
    }

}
