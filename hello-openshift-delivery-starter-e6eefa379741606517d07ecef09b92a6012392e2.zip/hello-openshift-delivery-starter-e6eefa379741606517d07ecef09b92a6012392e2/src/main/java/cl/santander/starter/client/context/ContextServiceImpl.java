package cl.santander.starter.client.context;

import java.util.HashMap;

import javax.annotation.PostConstruct;


import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;

import org.springframework.http.MediaType;
import org.springframework.stereotype.Component;
import org.springframework.web.reactive.function.BodyInserters;
import org.springframework.web.reactive.function.client.WebClient;

import com.fasterxml.jackson.databind.ObjectMapper;

import cl.santander.starter.config.DssConfig;


import reactor.core.publisher.Mono;

/**
 * Implementation of the ContextService Interface
 * 
 * @author n727779
 * @version 1.0.0 03/06/2020
 * 
 * technical information
 * APPLICATION_JSON_UTF8 (DEPRECATED) Fix Switch APPLICATION_JSON # https://github.com/spring-projects/spring-framework/issues/22788
 * BodyInserter.fromObject (DEPRECATED) Fix Swicth BodyInserter.fromObject https://github.com/spring-projects/spring-framework/commit/5bb8c47b147d38a58ddcbcc86f1acd3afc33ba54
 * Spanish:
 * 
 * WebClient: Es una interfaz que representa el punto de entrada principal para realizar solicitudes web.
 * ObjectMapper: proporciona funcionalidad para leer y escribir JSON, ya sea desde y hacia POJO básicos (Objetos Java simples y sencillos),
 * o hacia y desde un modelo de árbol JSON de propósito general (JsonNode), así como la funcionalidad relacionada para realizar conversiones
 *
 * @PostConstruct: es una anotación utilizada en un método que debe ejecutarse después de realizar la inyección de dependencia para realizar cualquier inicialización.
 *
 * @Component: es la anotación Spring más genérica. Una clase de Java decorada con @Component
 * se encuentra durante el escaneo de classpath y se registra en el contexto como un bean Spring.
 * 
 * @Autowired: Marca un constructor, campo, método de establecimiento o método de configuración para que los dispositivos de inyección de dependencias de Spring lo conecten automáticamente.
 *
 * English:
 * 
 * WebClient: WebClient is an interface representing the main entry point for performing web requests.
 * ObjectMapper: provides functionality for reading and writing JSON, either to and from basic POJOs (Plain Old Java Objects),
 *  or to and from a general-purpose JSON Tree Model (JsonNode), as well as related functionality for performing conversions.
 *  
 * @PostConstruct: is an annotation used on a method that needs to be executed after dependency injection is done to perform any initialization.
 * 
 * @Component: is the most generic Spring annotation. A Java class decorated with @Component
 *  is found during classpath scanning and registered in the context as a Spring bean.
 *  
 * @Autowired: Marks a constructor, field, setter method, or config method as to be autowired by Spring's dependency injection facilities. 
 *  
 * @author id20576 
 * @version v1.1.0 02/08/2020
 */

@Component
public class ContextServiceImpl implements ContextService {
	
	private final static Logger LOGGER = LoggerFactory.getLogger(ContextServiceImpl.class);

	@Autowired
	private DssConfig dss;
	private WebClient clientCtx;
	private ObjectMapper mapper;

	@PostConstruct
	public void init() {
		clientCtx = WebClient.create(dss.getContext().get("url"));
		mapper = new ObjectMapper();
	}//clousure constructor

	/**
	 * method putContext
	 * 
	 * @param String token
	 * @param String nameContext
	 * @param Object obj
	 * @param long timeToLive
	 * @return Mono<HttpStatus>
	 */
	@Override
	public Mono<HttpStatus> putContext(String token, String nameContext, Object obj, long timeToLive) {
		LOGGER.info("Put Context :: ".concat(nameContext));
		@SuppressWarnings("unchecked")
		HashMap<String, Object> map = mapper.convertValue(obj, HashMap.class);

		Mono<HttpStatus> result = clientCtx.put()
				.uri(builder -> builder.path("/v1/context/{nameContext}/{key}").queryParam("timeToLive", timeToLive).build(nameContext, token))
				.header(HttpHeaders.CONTENT_TYPE, MediaType.APPLICATION_JSON_VALUE).body(BodyInserters.fromValue(map))
				.exchange().map(status -> status.statusCode());
		return result;

	}// clousure method

	/**
	 * method getContext
	 * 
	 * @param String token
	 * @param String nameContext
	 */
	@Override
	public Mono<Object> getContext(String token, String nameContext) {

		LOGGER.info("Get Context :: ".concat(nameContext));
		return clientCtx.get().uri("/v1/context/{nameContext}/{key}", nameContext, token).exchange().flatMap(status -> {
			if (!status.statusCode().is2xxSuccessful())
				return Mono.empty();
			LOGGER.info("status: " + status.bodyToMono(Object.class));
			return status.bodyToMono(Object.class);
		});
	}// clousure method

	/**
	 * method patchContext
	 * @param String token
	 * @param String nameContext
	 * @param long timeToLive
	 */
	@Override
	public Mono<HttpStatus> patchContext(String token, String nameContext, Object obj, long timeToLive) {
		LOGGER.info("Patch Context :: ".concat(nameContext));
		@SuppressWarnings("unchecked")
		HashMap<String, Object> map = mapper.convertValue(obj, HashMap.class);

		Mono<HttpStatus> result = clientCtx.patch()
				.uri(builder -> builder.path("/v1/context/{nameContext}/{key}").queryParam("timeToLive", timeToLive).build(nameContext, token))
				.header(HttpHeaders.CONTENT_TYPE, MediaType.APPLICATION_JSON_VALUE).body(BodyInserters.fromValue(map))
				.exchange().map(status -> status.statusCode());
		return result;
	}// clousure method

	/**
	 * method postContext
	 * 
	 * @param String token
	 * @param String nameContext
	 * @param Object obj
	 * @param long timeToLive 
	 */
	@Override
	public Mono<HttpStatus> postContext(String token, String nameContext, Object obj, long timeToLive) {
		LOGGER.info("Post Context :: ".concat(nameContext));
		@SuppressWarnings("unchecked")
		HashMap<String, Object> map = mapper.convertValue(obj, HashMap.class);

		Mono<HttpStatus> result = clientCtx.post()
				.uri(builder -> builder.path("/v1/context/{nameContext}/{key}").queryParam("timeToLive", timeToLive).build(nameContext, token))
				.contentType(MediaType.APPLICATION_JSON).accept(MediaType.APPLICATION_JSON)
				.body(BodyInserters.fromValue(map)).exchange().map(status -> status.statusCode());
		return result;
	}// clousure method
	
	/**
	 * method deleteContext
	 * @param String token
	 * @param String nameContext 
	 */
	@Override
	public Mono<HttpStatus> deleteContext(String token, String nameContext) {
		LOGGER.info("Delete Context :: ".concat(nameContext));
		Mono<HttpStatus> result = clientCtx.delete().uri(builder->builder.path("/v1/context/{nameContext}/{key}")
				.build(nameContext, token)).exchange()
				.map(status -> status.statusCode());

		return result;
	}


}
