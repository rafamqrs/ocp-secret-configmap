package cl.santander.starter.config;

import java.util.HashMap;

import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.boot.context.properties.EnableConfigurationProperties;
import org.springframework.context.annotation.Configuration;
/**
 * tecnichal information:
 * 
 * spanish:
 * @Configuration: Anotación para definir una clase de configuracion  para el framework
 * @ConfigurationProperties: Anotación para configuración externalizada. Agregue esto a una definición de clase o un método 
 * @Bean en una clase @Configuration si desea vincular y validar algunas Propiedades externas 
 * en este caso se hace referencia a la seccion beaas del archivo application.yml
 * 
 * @EnableConfigurationProperties: esta explicitamente activado al usar @ConfigurationProperties
 * 
 * english:
 * @Configuration: Annotation to define a configuration class for the framework
 * @ConfigurationProperties: Annotation for externalized configuration. Add this to a class definition or a 
 * @Bean method in a @Configuration class if you want to bind and validate some external Properties
 * in this case reference is made to the beaas section of the application.yml file
 * 
 * @EnableConfigurationProperties: It is explicitly activated when using @ConfigurationProperties
 * 
 * @author id20576
 * @version v1.1.0 02/08/2020
 * 
 *
 */
@Configuration
@EnableConfigurationProperties
@ConfigurationProperties(prefix = "banking")
public class Constants {
	
	private HashMap<String, String> constants;

	public HashMap<String, String> getConstants() {
		return constants;
	}

	public void setConstants(HashMap<String, String> constants) {
		this.constants = constants;
	}


	
}
