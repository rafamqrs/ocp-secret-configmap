package cl.santander.starter.client.functionalLogging;

import com.fasterxml.jackson.core.JsonProcessingException;

import cl.santander.starter.domain.FunctionalLogging;

public interface FunctionalLoggingSvc {

    public void send(String channel, FunctionalLogging data) throws JsonProcessingException;

}
